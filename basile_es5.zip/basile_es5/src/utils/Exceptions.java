package utils;

public class Exceptions {

    public static class NoDeclarationError extends Exception{

        public NoDeclarationError(String type, String v){
            super(type+"non dichiarata: "+v);
        }

    }

    public static class NoDeclaration extends Exception{
        public NoDeclaration(String s){
            super("variabile non dichiarata di "+ s);
        }
    }
}
