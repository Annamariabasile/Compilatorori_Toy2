package node;

import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class Type extends DefaultMutableTreeNode implements Visitable {

    String tipo;

    public Type(String tipo) {
        super("type");
        super.add(new DefaultMutableTreeNode(tipo)); //per le stringhe
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
