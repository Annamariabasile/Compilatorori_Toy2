package node;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.statement.Statement;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class Body extends DefaultMutableTreeNode implements Visitable {

    ArrayList<DeclsOP> vardecls;
    ArrayList<Statement> statement;


    public Body(ArrayList<DeclsOP> vardecl, ArrayList<Statement> stat) {
        super("Body");

        this.vardecls = vardecl;
        this.statement = stat;

        for(DeclsOP v: vardecl){
            super.add(v);
        }
        for (Statement s: stat){
            super.add(s);
        }
    }
    public ArrayList<DeclsOP> getVardecls() {
        return vardecls;
    }

    public void setVardecls(ArrayList<DeclsOP> vardecls) {
        this.vardecls = vardecls;
    }

    public ArrayList<Statement> getStatement() {
        return statement;
    }

    public void setStatement(ArrayList<Statement> statement) {
        this.statement = statement;
    }


    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
