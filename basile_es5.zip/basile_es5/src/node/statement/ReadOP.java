package node.statement;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;

import java.util.ArrayList;

public class ReadOP extends Statement implements Visitable {

    ArrayList<Expr> ioargs;

    public ReadOP( ArrayList<Expr> ioargs) {
        super("ReadOP");

        for(Expr e: ioargs){
            super.add(e);
        }

        this.ioargs = ioargs;
    }

    public ArrayList<Expr> getIoargs() {
        return ioargs;
    }

    public void setIoargs(ArrayList<Expr> ioargs) {
        this.ioargs = ioargs;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
