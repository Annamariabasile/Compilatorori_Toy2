package node.statement;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;

import java.util.ArrayList;

public class WriteReturnOP extends Statement implements Visitable {

    ArrayList<Expr> ioargs;

    public WriteReturnOP(ArrayList<Expr> ioargs) {
        super("WriteReturnOP");
        //aggiunta delle dichiarazioni all'albero
        for(Expr e: ioargs){
            super.add(e);
        }
        this.ioargs = ioargs;
    }

    public ArrayList<Expr> getIoargs() {
        return ioargs;
    }

    public void setIoargs(ArrayList<Expr> ioargs) {
        this.ioargs = ioargs;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
