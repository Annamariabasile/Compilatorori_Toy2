package node.statement;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;
import java.util.ArrayList;

public class ReturnOP extends Statement implements Visitable {

    ArrayList<Expr> exprs;

    public ReturnOP( ArrayList<Expr> exprs) {
        super("ReturnOP");
        for(Expr e: exprs){
            super.add(e);
        }
        this.exprs = exprs;
    }
    public ArrayList<Expr> getExprs() {
        return exprs;
    }

    public void setExprs(ArrayList<Expr> exprs) {
        this.exprs = exprs;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }

}
