package node.statement;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Body;
import node.Expr.Expr;
public class WhileOP extends Statement implements Visitable {
    Expr espressione;
    Body corpo;

    private SymbolTable symbolTable;

    public WhileOP(Expr espressione, Body corpo) {
        super("While");
        this.espressione=espressione;
        this.corpo=corpo;

        super.add(espressione);
        super.add(corpo);
    }

    public Expr getEspressione() {
        return espressione;
    }

    public void setEspressione(Expr espressione) {
        this.espressione = espressione;
    }

    public Body getCorpo() {
        return corpo;
    }

    public void setCorpo(Body corpo) {
        this.corpo = corpo;
    }


    public SymbolTable getSymbolTable() {
        return symbolTable;
    }

    public void setSymbolTable(SymbolTable symbolTable) {
        this.symbolTable = symbolTable;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
