package node.statement;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class Statement extends DefaultMutableTreeNode implements Visitable {

    public Statement(String name) {
        super(name);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
