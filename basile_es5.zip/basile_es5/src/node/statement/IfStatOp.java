package node.statement;

import java.util.ArrayList;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;
import node.Body;

public class IfStatOp extends Statement implements Visitable {

    Expr expr;
    Body corpo;

    ArrayList<ElifOp> listelif;
    Body elseBody;
    private SymbolTable symbolTableIf;

    private SymbolTable symbolTableElse;

    public IfStatOp(Expr expr, Body corpo, ArrayList<ElifOp> listelif, Body elseBody) {
        super("IfStat");

        super.add(expr);
        super.add(corpo);
        for(ElifOp l: listelif){
            super.add(l);
        }
        super.add(elseBody);

        this.expr = expr;
        this.corpo = corpo;
        this.listelif = listelif;
        this.elseBody = elseBody;
    }

    public IfStatOp(Expr expr, Body corpo, ArrayList<ElifOp> listelif) {
        super("IfStat");

        super.add(expr);
        super.add(corpo);
        for(ElifOp l: listelif){
            super.add(l);
        }

        this.expr = expr;
        this.corpo = corpo;
        this.listelif = listelif;
    }

    public IfStatOp( Expr expr, Body corpo, Body elseBody) {
        super("IfStat");

        super.add(expr);
        super.add(corpo);
        super.add(elseBody);

        this.expr = expr;
        this.corpo = corpo;
        this.elseBody = elseBody;
    }

    public IfStatOp(Expr expr, Body corpo) {
        super("IfStat");

        super.add(expr);
        super.add(corpo);

        this.expr = expr;
        this.corpo = corpo;
    }

    public Expr getExpr() {
        return expr;
    }

    public void setExpr(Expr expr) {
        this.expr = expr;
    }

    public Body getCorpo() {
        return corpo;
    }

    public void setCorpo(Body corpo) {
        this.corpo = corpo;
    }

    public ArrayList<ElifOp> getListelif() {
        return listelif;
    }

    public void setListelif(ArrayList<ElifOp> listelif) {
        this.listelif = listelif;
    }

    public Body getElseBody() {
        return elseBody;
    }

    public void setElseBody(Body elseBody) {
        this.elseBody = elseBody;
    }

    public SymbolTable getSymbolTableIf() {
        return symbolTableIf;
    }

    public void setSymbolTableIf(SymbolTable symbolTableIf) {
        this.symbolTableIf = symbolTableIf;
    }

    public SymbolTable getSymbolTableElse() {
        return symbolTableElse;
    }

    public void setSymbolTableElse(SymbolTable symbolTableElse) {
        this.symbolTableElse = symbolTableElse;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
