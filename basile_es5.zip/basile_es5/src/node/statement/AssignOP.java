package node.statement;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;
import node.Expr.Identifier;

import java.util.ArrayList;

public class AssignOP extends Statement implements Visitable {
    ArrayList<Identifier> ids;

    ArrayList<Expr> exprs;


    //costruttore

    public AssignOP(ArrayList<Identifier> ids, ArrayList<Expr> exprs) {
        super("AssignOp");

        for(Identifier i: ids){
            super.add(i);
        }
        for(Expr e: exprs){
            super.add(e);
        }

        this.ids = ids;
        this.exprs = exprs;
    }

    public ArrayList<Identifier> getIds() {
        return ids;
    }

    public void setIds(ArrayList<Identifier> ids) {
        this.ids = ids;
    }

    public ArrayList<Expr> getExprs() {
        return exprs;
    }

    public void setExprs(ArrayList<Expr> exprs) {
        this.exprs = exprs;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}


