package node.statement;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;
import node.Body;
public class ElifOp extends Statement implements Visitable {

    Expr espressione;
    Body corpo;
    private SymbolTable symbolTableElIf;

    public ElifOp( Expr espressione, Body corpo) {
        super("Elif");

        super.add(espressione);
        super.add(corpo);

        this.espressione = espressione;
        this.corpo = corpo;
    }

    public Expr getEspressione() {
        return espressione;
    }

    public void setEspressione(Expr espressione) {
        this.espressione = espressione;
    }

    public Body getCorpo() {
        return corpo;
    }

    public void setCorpo(Body corpo) {
        this.corpo = corpo;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }

    public SymbolTable getSymbolTableElIf() {
        return symbolTableElIf;
    }

    public void setSymbolTableElIf(SymbolTable symbolTableElIf) {
        this.symbolTableElIf = symbolTableElIf;
    }
}
