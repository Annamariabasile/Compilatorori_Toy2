package node;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Identifier;

import javax.swing.tree.DefaultMutableTreeNode;


public class ProcParams extends DefaultMutableTreeNode implements Visitable {

    Identifier id;
    Type tipo;


    public ProcParams(Identifier id, Type tipo) {
        super("ProcParams");
        super.add(id);
        super.add(tipo);

        this.id = id;
        this.tipo = tipo;

    }

    public Identifier getId() {
        return id;
    }

    public void setId(Identifier id) {
        this.id = id;
    }

    public Type getTipo() {
        return tipo;
    }

    public void setTipo(Type tipo) {
        this.tipo = tipo;
    }


    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
