package node;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Identifier;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class Function extends DefaultMutableTreeNode implements Visitable {

    Identifier id; //id della funzione
    ArrayList<FuncParams> parametri; // parametri in input

    ArrayList<Type> tipi; //tipi di ritorno della funzione
    Body corpo; //corpo della funzione

    private SymbolTable symbolTableFunc;

    public Function(Identifier id, ArrayList<FuncParams> parametri, ArrayList<Type> tipi, Body corpo) {
        super("Function");
        this.id = id;
        this.parametri = parametri;
        this.tipi = tipi;
        this.corpo = corpo;
        super.add(id); //id
        for(FuncParams f: parametri){
            super.add(f);
        }
        for(Type t: tipi){
            super.add(t);
        }
        super.add(corpo);
    }

    public Identifier getId() {
        return id;
    }

    public void setId(Identifier id) {
        this.id = id;
    }

    public ArrayList<FuncParams> getParametri() {
        return parametri;
    }

    public void setParametri(ArrayList<FuncParams> parametri) {
        this.parametri = parametri;
    }

    public ArrayList<Type> getTipi() {
        return tipi;
    }

    public void setTipi(ArrayList<Type> tipi) {
        this.tipi = tipi;
    }

    public Body getCorpo() {
        return corpo;
    }

    public void setCorpo(Body corpo) {
        this.corpo = corpo;
    }

    public SymbolTable getSymbolTableFunc() {
        return symbolTableFunc;
    }

    public void setSymbolTableFunc(SymbolTable symbolTableFunc) {
        this.symbolTableFunc = symbolTableFunc;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
