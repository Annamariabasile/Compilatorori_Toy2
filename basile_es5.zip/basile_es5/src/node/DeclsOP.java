package node;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.ConstOp;
import node.Expr.Identifier;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class DeclsOP extends DefaultMutableTreeNode implements Visitable {

    ArrayList<Identifier> id;
    Type tipo;
    ArrayList<ConstOp> costanti;

    //costruttore 1 con id e tipo
    public DeclsOP(ArrayList<Identifier> id, Type tipo) {
        super("Decls");
        for(Identifier i: id){
            super.add(i);
        }
        super.add(tipo);
        this.id = id;
        this.tipo = tipo;
    }

    //costruttore 2 con id e costante
    public DeclsOP(ArrayList<Identifier> id, ArrayList<ConstOp> costanti) {
        super("Decls");
        for(Identifier i: id){
            super.add(i);
        }
        for(ConstOp c: costanti){
            super.add(c);
        }
        this.id = id;
        this.costanti = costanti;
    }

    public ArrayList<Identifier> getId() {
        return id;
    }

    public void setId(ArrayList<Identifier> id) {
        this.id = id;
    }

    public Type getTipo() {
        return tipo;
    }

    public void setTipo(Type tipo) {
        this.tipo = tipo;
    }

    public ArrayList<ConstOp> getCostanti() {
        return costanti;
    }

    public void setCostanti(ArrayList<ConstOp> costanti) {
        this.costanti = costanti;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
