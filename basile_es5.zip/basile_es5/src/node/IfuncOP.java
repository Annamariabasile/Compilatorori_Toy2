package node;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Identifier;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class IfuncOP extends DefaultMutableTreeNode implements Visitable {

    Identifier id;
    ArrayList<FuncParams> parametri;
    Body bodyIfunc;


    SymbolTable symbolTableIfunc;

    public IfuncOP(Identifier id, ArrayList<FuncParams> parametri, Body bodyIfunc){
        super("IFunc");
        this.id=id;
        this.parametri=parametri;
        this.bodyIfunc=bodyIfunc;

        super.add(id);
        for(FuncParams p: parametri){
            super.add(p);
        }

        super.add(bodyIfunc);
    }

    public Identifier getId() {
        return id;
    }

    public void setId(Identifier id) {
        this.id = id;
    }

    public ArrayList<FuncParams> getParametri() {
        return parametri;
    }

    public void setParametri(ArrayList<FuncParams> parametri) {
        this.parametri = parametri;
    }

    public Body getBodyIfunc() {
        return bodyIfunc;
    }

    public void setBodyIfunc(Body bodyIfunc) {
        this.bodyIfunc = bodyIfunc;
    }

    public SymbolTable getSymbolTableIfunc() {
        return symbolTableIfunc;
    }

    public void setSymbolTableIfunc(SymbolTable symbolTableIfunc) {
        this.symbolTableIfunc = symbolTableIfunc;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
