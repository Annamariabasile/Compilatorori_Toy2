package node.Expr;

import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class Identifier extends Expr implements Visitable {

    String attribute;
    String lessema;


    //costruttore senza attributo

    public Identifier(String lessema) {
        super("Identifier");


        super.add(new DefaultMutableTreeNode(lessema));

        this.attribute="";
        this.lessema = lessema;

    }

    //costruttore con attributo
    public Identifier( String attribute, String lessema) {
        super("Identifier");
        super.add(new DefaultMutableTreeNode(attribute));
        super.add(new DefaultMutableTreeNode(lessema));
        this.attribute = attribute;
        this.lessema = lessema;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public String getLessema() {
        return lessema;
    }

    public void setLessema(String lessema) {
        this.lessema = lessema;
    }


    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
