package node.Expr;

import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class Relop extends Expr implements Visitable {

    String tipoOp;
    Expr expr1;
    Expr expr2;

    public Relop( String tipoOp, Expr expr1, Expr expr2) {
        super("Relop");

        super.add(new DefaultMutableTreeNode(tipoOp));
        super.add(expr1);
        super.add(expr2);

        this.tipoOp = tipoOp;
        this.expr1 = expr1;
        this.expr2 = expr2;
    }

    public String getTipoOp() {
        return tipoOp;
    }

    public void setTipoOp(String tipoOp) {
        this.tipoOp = tipoOp;
    }

    public Expr getExpr1() {
        return expr1;
    }

    public void setExpr1(Expr expr1) {
        this.expr1 = expr1;
    }

    public Expr getExpr2() {
        return expr2;
    }

    public void setExpr2(Expr expr2) {
        this.expr2 = expr2;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
