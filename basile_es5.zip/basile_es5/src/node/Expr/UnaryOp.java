package node.Expr;

import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class UnaryOp extends Expr implements Visitable {

    String type;
    Expr expr;

    public UnaryOp(String type, Expr expr) {
        super("UnaryOp");

        super.add(expr);
        super.add(new DefaultMutableTreeNode(type));

        this.expr = expr;
        this.type = type;
    }

    public Expr getExpr() {
        return expr;
    }

    public void setExpr(Expr expr) {
        this.expr = expr;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
