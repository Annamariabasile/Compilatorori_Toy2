package node.Expr;

import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class ConstOp extends Expr implements Visitable {
    String lessema;
    String costante;

    public ConstOp(String costante, String lessema) {
        super("ConstOp");
        super.add(new DefaultMutableTreeNode(costante));
        super.add(new DefaultMutableTreeNode(lessema));

        this.lessema = lessema;
        this.costante=costante;
    }

    public ConstOp(String lessema){
        super("ConstOp");
        super.add(new DefaultMutableTreeNode(lessema));
        this.lessema=lessema;
    }

    public String getLessema() {
        return lessema;
    }

    public void setLessema(String lessema) {
        this.lessema = lessema;
    }

    public String getCostante() {
        return costante;
    }

    public void setCostante(String costante) {
        this.costante = costante;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
