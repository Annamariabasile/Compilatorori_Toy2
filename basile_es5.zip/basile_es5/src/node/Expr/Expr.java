package node.Expr;

import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;

public class Expr extends DefaultMutableTreeNode implements Visitable {
    String espressione;
    String mode;

    String exprType;

    public Expr(String espressione) {
        super(espressione);
        this.espressione = espressione;
    }

    public Expr(String espressione, String mode) {
        super(espressione);
        this.espressione = espressione;
        this.mode = mode;
    }

    public String getEspressione() {
        return espressione;
    }

    public void setEspressione(String espressione) {
        this.espressione = espressione;
    }


    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getExprType() {
        return exprType;
    }

    public void setExprType(String type) {
        this.exprType = type;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }


}
