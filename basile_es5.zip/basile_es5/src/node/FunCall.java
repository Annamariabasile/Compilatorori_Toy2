package node;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;
import node.Expr.Identifier;

import java.util.ArrayList;

public class FunCall extends Expr implements Visitable {

    Identifier id;
    ArrayList<Expr> exprs;


    //costruttore

    public FunCall(Identifier id, ArrayList<Expr> exprs) {
        super("funcall");
        //Aggiunta all'albero delle dichiarazioni
        super.add(id);

        for (Expr e : exprs) {
            super.add(e);
        }
        this.id = id;
        this.exprs = exprs;
    }

    public FunCall( Identifier id) {
        super("funcall");
        super.add(id);
        this.id = id;
    }

    //get and set

    public Identifier getId() {
        return id;
    }

    public void setId(Identifier id) {
        this.id = id;
    }

    public ArrayList<Expr> getExprs() {
        return exprs;
    }

    public void setExprs(ArrayList<Expr> exprs) {
        this.exprs = exprs;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}