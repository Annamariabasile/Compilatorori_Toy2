package node;

import Visitors.SemanticVisitorScope;
import Visitors.Visitable;
import Visitors.Visitor;

import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class Iter extends DefaultMutableTreeNode implements Visitable {

    ArrayList<DeclsOP> variabili;
    Function funzione;
    Procedure procedura;
    //ArrayList<Iter> iter;

    IfuncOP ifunc;



    public Iter(ArrayList<DeclsOP> variabili) {
        super("iter");
        if (variabili!=null) {
        for(DeclsOP d: variabili){
            super.add(d);
        }}

        this.variabili = variabili;
    }


    //costruttore 2 funzione

    public Iter(Function funzione) {
        super("iter");
        super.add(funzione);
        this.funzione = funzione;
    }


    //costruttore 3 procedura

    public Iter(Procedure procedura) {
        super("iter");
        super.add(procedura);

        this.procedura = procedura;
    }

    public Iter(IfuncOP ifunc){
        super("iter");
        super.add(ifunc);

        this.ifunc=ifunc;
    }

    public ArrayList<DeclsOP> getVariabili() {
        return variabili;
    }

    public void setVariabili(ArrayList<DeclsOP> variabili) {
        this.variabili = variabili;
    }

    public Function getFunzione() {
        return funzione;
    }

    public void setFunzione(Function funzione) {
        this.funzione = funzione;
    }

    public Procedure getProcedura() {
        return procedura;
    }

    public void setProcedura(Procedure procedura) {
        this.procedura = procedura;
    }

    public IfuncOP getIfunc() {
        return ifunc;
    }

    public void setIfunc(IfuncOP ifunc) {
        this.ifunc = ifunc;
    }

    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}

