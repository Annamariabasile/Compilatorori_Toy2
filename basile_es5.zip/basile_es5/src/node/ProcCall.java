package node;

import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;
import node.Expr.Identifier;
import node.statement.Statement;

import java.util.ArrayList;
import java.util.List;

public class ProcCall extends Statement implements Visitable {
    Identifier id;
    ArrayList<Expr> procexpr;

    public ProcCall(Identifier id, ArrayList<Expr> procexpr) {
        super("ProcCall");
        super.add(id);
        for(Expr e: procexpr){
            super.add(e);
        }
        this.id = id;
        this.procexpr = procexpr;
    }

    public ProcCall( Identifier id) {
        super("ProcCall");
        this.id = id;
    }

    public Identifier getId() {
        return id;
    }

    public void setId(Identifier id) {
        this.id = id;
    }

    public ArrayList<Expr> getProcexpr() {
        return procexpr;
    }

    public void setProcexpr(ArrayList<Expr> procexpr) {
        this.procexpr = procexpr;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
