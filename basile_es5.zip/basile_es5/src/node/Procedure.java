package node;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Identifier;

import javax.swing.tree.DefaultMutableTreeNode;
import java.security.PrivateKey;
import java.util.ArrayList;

public class Procedure extends DefaultMutableTreeNode implements Visitable {
    Identifier id;
    ArrayList<ProcParams> parametri;
    Body corpo;

    private SymbolTable symbolTableProc;

    public Procedure(Identifier id, ArrayList<ProcParams> parametri, Body corpo) {
        super("Procedure");
        super.add(id);
        if(parametri!=null) {
            for (ProcParams p : parametri) {
                super.add(p);
            }
        }
        super.add(corpo);

        this.id = id;
        this.parametri = parametri;
        this.corpo = corpo;
    }

    public Identifier getId() {
        return id;
    }

    public void setId(Identifier id) {
        this.id = id;
    }

    public ArrayList<ProcParams> getParametri() {
        return parametri;
    }

    public void setParametri(ArrayList<ProcParams> parametri) {
        this.parametri = parametri;
    }

    public Body getCorpo() {
        return corpo;
    }

    public void setCorpo(Body corpo) {
        this.corpo = corpo;
    }

    public SymbolTable getSymbolTableProc() {
        return symbolTableProc;
    }

    public void setSymbolTableProc(SymbolTable symbolTableProc) {
        this.symbolTableProc = symbolTableProc;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }
}
