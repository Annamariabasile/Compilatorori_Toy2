package node;

import SymbolTable.SymbolTable;
import Visitors.Visitable;
import Visitors.Visitor;
import node.Expr.Expr;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import java.util.ArrayList;

public class Program extends DefaultMutableTreeNode implements Visitable {
    ArrayList<Iter> iterwithoutprocedure;
    Procedure procedura;
    ArrayList<Iter> iter;
    private SymbolTable symbolTable;

    public Program(ArrayList<Iter> iterwithoutprocedure, Procedure procedura, ArrayList<Iter>iter) {
        super("Program");

        for (Iter i : iterwithoutprocedure) {
            super.add(i);
        }
        super.add(procedura);
       for(Iter it: iter) {
           super.add(it);
       }


        this.iterwithoutprocedure = iterwithoutprocedure;
        this.procedura = procedura;
        this.iter = iter;
    }

    public ArrayList<Iter> getIterwithoutprocedure() {
        return iterwithoutprocedure;
    }

    public void setIterwithoutprocedure(ArrayList<Iter> iterwithoutprocedure) {
        this.iterwithoutprocedure = iterwithoutprocedure;
    }

    public Procedure getProcedura() {
        return procedura;
    }

    public void setProcedura(Procedure procedura) {
        this.procedura = procedura;
    }

    public ArrayList<Iter> getIter() {
        return iter;
    }

    public void setIter(ArrayList<Iter> iter) {
        this.iter = iter;
    }




    public void setSymbolTable(SymbolTable symbolTable){
        this.symbolTable=symbolTable;
    }

    public SymbolTable getSymbolTable(){
        return this.symbolTable;
    }

    @Override
    public Object accept(Visitor v) throws Exception {
        return v.visit(this);
    }

}
