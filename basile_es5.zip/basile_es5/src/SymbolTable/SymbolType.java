package SymbolTable;

import node.Type;

import java.util.ArrayList;

public class SymbolType {
    private ArrayList<Type> inTypeList = new ArrayList<>();
    private ArrayList<Type> outTypeList =  new ArrayList<>();


    public SymbolType(ArrayList<Type> inTypeList, ArrayList<Type> outTypeList) { //per le funzioni
        this.inTypeList = inTypeList;
        this.outTypeList = outTypeList;
    }
    public SymbolType(Type inType) { //per le dichiarazioni di variabili
        inTypeList.add(inType);
    }

    public SymbolType(ArrayList<Type> outTypeList) {
        this.outTypeList = outTypeList;
    }

    public ArrayList<Type> getInTypeList() {
        return inTypeList;
    }

    public void setInTypeList(ArrayList<Type> inTypeList) {
        this.inTypeList = inTypeList;
    }

    public void addInTypeList(Type type){
        this.inTypeList.add(type);
    }

    public ArrayList<Type> getOutTypeList() {
        return outTypeList;
    }

    public void setOutTypeList(ArrayList<Type> outTypeList) {
        this.outTypeList = outTypeList;
    }
    public void addOutType(Type type){
        this.outTypeList.add(type);
    }
    public void addOutTypeList(ArrayList<Type> typeList){
        this.outTypeList.addAll(typeList);
    }

    @Override
    public String toString() {
        String intypes = "";
        String outtypes = "";
        for(Type type: inTypeList){
            intypes += type.getTipo().toString();
            intypes +=" ";
        }
        for(Type type: outTypeList){
            outtypes += type.getTipo().toString();
            outtypes +=" ";
        }
        return
                "in type=" + intypes +
                ", out type=" + outtypes
                ;
    }


}
