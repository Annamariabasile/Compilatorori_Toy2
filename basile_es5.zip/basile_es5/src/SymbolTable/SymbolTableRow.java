package SymbolTable;

public class SymbolTableRow {


        private String symbol; //lessema

        private String kind;   //quale nodo è

        private SymbolType type;  //i tipi

        private String properties;

        public SymbolTableRow(String symbol, String kind, SymbolType type, String properties){
            this.symbol=symbol;
            this.kind=kind;
            this.type=type;
            this.properties=properties;

        }

        public String getSymbol() {
            return symbol;
        }

        public String getKind() {
            return kind;
        }

        public SymbolType getType() {
            return type;
        }

        public String getProperties() {
            return properties;
        }

        @Override
        public String toString() {
            return "Symbol: " + symbol + ", Kind: " + kind + ", Type: " + type.toString() + ", Properties: " + properties;

        }

}
