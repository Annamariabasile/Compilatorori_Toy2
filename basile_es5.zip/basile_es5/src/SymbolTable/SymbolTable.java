package SymbolTable;

import java.util.ArrayList;

public class SymbolTable {

    private SymbolTable father;    //tabella padre

    private String scope;


    private ArrayList<SymbolTableRow> listRow; //righe della tabella

    private static boolean shadowing=true; //per controllare se nello scope c'è gia l'id



    public SymbolTable(){
        father=null;
        listRow=new ArrayList<SymbolTableRow>();
    }

    public SymbolTable(SymbolTable father, ArrayList<SymbolTableRow> listRow, String scope){
        this.father=father;
        this.listRow=listRow;
        this.scope=scope;

    }


    //get e set

    public void setScope(String scope){
        this.scope=scope;
    }

    public String getScope(){return scope;}

    public ArrayList<SymbolTableRow> getListRow() {return this.listRow;}

    public void setFather(SymbolTable father){
        this.father=father;
    }

    public SymbolTable getFather() {return this.father;}

    @Override
    public String toString() {
        System.out.println("SymbolTable: "+scope);
        if(father!=null) System.out.println("Father: "+father.getScope());
        for (SymbolTableRow row:listRow)
            System.out.println(row.toString());
        System.out.println();
        return "";
    }

    //controlla la lista delle symbol table se esiste già il lessema
    public SymbolTableRow lookup(String id){
        SymbolTable symbolTable=this;
        while (symbolTable!=null){
            for(SymbolTableRow r:symbolTable.listRow) {
                if (r.getSymbol().equals(id)) {
                    //System.out.println("fr" + r.getType().getInTypeList() + " b  " + id);
                    return r;
                }
            }
            symbolTable=symbolTable.father;
        }
        return null;
    }

    //controlla se nella tabella attuale esiste il lessema
    public boolean probe(String x){
        for(SymbolTableRow r:this.listRow)
            if(r.getSymbol().equals(x))
                return true;
        return false;
    }

    //aggiunge una riga alla tabella dei simboli
    public void addRow(SymbolTableRow row) throws Exception {

        //se lo shadowing è true, controlla la tabella attuale e se si può aggiungere lo fa
        if (shadowing) {
            if (probe(row.getSymbol()))
                throw new Exception("Elemento: "+row.getSymbol()+" è stato già dichiarato");
            else
                listRow.add(row);
        }

        //se lo shadowing è false, cerca la prima tabella in cui è legale l'inserimento
        else {

            SymbolTable symbolTable = this;
            while (symbolTable != null) {
                if (symbolTable.probe(row.getSymbol()) | (row.getSymbol().equals(symbolTable.scope) && !row.getSymbol().equals("Root")))
                    throw new Exception();
                else
                    symbolTable = symbolTable.getFather();
            }
            listRow.add(row);
        }
    }

}
