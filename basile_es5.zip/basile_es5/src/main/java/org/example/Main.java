package main.java.org.example;

import Visitors.CodeGenerationVisitor;
import Visitors.SemanticVisitorScope;
import Visitors.TypeVisitor;
import main.Lexer;
import main.parser;
import node.Program;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.io.File;
import java.io.FileReader;

public class Main {


    public static void main(String[] args) throws Exception {
        JTree tree;
        File input = new File(args[0]);
        //File input = new File("C:\\Users\\abasi\\Desktop\\compilatori\\esercitazioni\\basile_es5\\src\\main\\java\\org\\example\\sample.inp");
        parser p = new parser(new Lexer(new FileReader(input)));

        DefaultMutableTreeNode root = (DefaultMutableTreeNode) p.parse().value;

        ((Program) root).accept(new SemanticVisitorScope());
        ((Program) root).accept(new TypeVisitor());
        ((Program) root).accept(new CodeGenerationVisitor(input.getName().substring(0, input.getName().lastIndexOf('.'))));
     //   int a=0;


        try {
           // DefaultMutableTreeNode root = (DefaultMutableTreeNode) p.debug_parse().value;
            tree=new JTree(root);

            JFrame framePannello=new JFrame();
            framePannello.setSize(400, 400);
            JScrollPane treeView = new JScrollPane(tree);
            framePannello.add(treeView);
            framePannello.setVisible(true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
}