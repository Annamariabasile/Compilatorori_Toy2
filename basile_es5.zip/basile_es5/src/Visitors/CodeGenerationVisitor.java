package Visitors;

import SymbolTable.*;
import node.*;
import node.Expr.*;
import node.statement.*;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class CodeGenerationVisitor implements Visitor {

    private SymbolTable currentScope;
    public static String FILE_NAME;
    private static File outFile;
    private static FileWriter writer;

    private Identifier funId;

    private static int currentTab = 0;
    private boolean main = false;

    Procedure pMain = null;

    public CodeGenerationVisitor(String filename) {
        FILE_NAME = filename+".c";
    }

    @Override
    public Object visit(Program program) throws Exception {

        outFile= new File(FILE_NAME);
        if(!(new File("test_files" + File.separator + "c_out" + File.separator)).exists()){
            new File(("test_files" + File.separator + "c_out" + File.separator)).mkdir();
        }

        outFile = new File("test_files" + File.separator + "c_out" + File.separator + FILE_NAME);
        outFile.createNewFile();
        writer = new FileWriter(outFile);
        addBaseLibraries();
        addHelperFunctions();
        currentScope = program.getSymbolTable();

        ArrayList<Iter> iters= program.getIter();
        iters.addAll(program.getIterwithoutprocedure());


        //creo le struct per i tipi di ritorno delle funzioni
        for(Iter i: iters){
            if(i.getFunzione()!=null){
                if(i.getFunzione().getParametri().size()>1){
                    int x;
                    writer.write("typedef struct{\n");
                    for(int j=0; j<i.getFunzione().getTipi().size(); j++){
                        Type type= i.getFunzione().getTipi().get(j);
                        writer.write("\t");
                        type.accept(this);
                        writer.write(" value" + j + ";\n");
                    }
                    writer.write("} ");
                    i.getFunzione().getId().accept(this);
                    writer.write("Struct;\n\n");
                }
            }
        }

        for(Iter i: iters) {
            if(i.getVariabili()!=null){
                for(DeclsOP d: i.getVariabili()){
                    d.accept(this);
                }
            //creo i le firme dei metodi
            }else if (i.getFunzione()!=null){
                currentScope= i.getFunzione().getSymbolTableFunc();
                //al posto di getTipi() c'era getParametri()
                if(i.getFunzione().getTipi().size()>1){
                    i.getFunzione().getId().accept(this);
                    writer.write("Struct");
                }else {
                    i.getFunzione().getTipi().get(0).accept(this);
                }
                writer.write(" ");
                i.getFunzione().getId().accept(this);
                writer.write("(");
                //caso in cui ci sono più parametri ed inserisco la virgola
                if(i.getFunzione().getParametri().size()>1){
                    for(int j=0; j<i.getFunzione().getParametri().size()-1; j++){
                        i.getFunzione().getParametri().get(j).accept(this);
                        writer.write(", ");
                    }
                }
                //caso in cui non inserisco la virgola
                if(!i.getFunzione().getParametri().isEmpty()){
                    i.getFunzione().getParametri().get(i.getFunzione().getParametri().size()-1).accept(this);
                }
                writer.write(");\n");
                currentScope=i.getFunzione().getSymbolTableFunc().getFather();
            }else if(i.getProcedura()!=null){
                //currentScope= i.getProcedura().getSymbolTableProc();
                if(!(i.getProcedura().getId().getLessema().equals("main"))){
                    writer.write("void ");
                    i.getProcedura().getId().accept(this);
                    writer.write(" (");
                    //caso in cui inserisco la virgola
                    if(i.getProcedura().getParametri().size()>1){
                        for(int j=0; j<i.getProcedura().getParametri().size()-1; j++ ){
                            i.getProcedura().getParametri().get(j).accept(this);
                            writer.write(", ");
                        }
                    }
                    //non inserisco la virgola
                    if(i.getProcedura()!=null){
                        i.getProcedura().getParametri().get(i.getProcedura().getParametri().size()-1).accept(this);
                    }
                    writer.write(");\n\n");
                }
            } else if (i.getIfunc()!=null) {

                currentScope= i.getIfunc().getSymbolTableIfunc();
                //al posto di getTipi() c'era getParametri()
                writer.write("int");
                writer.write(" ");
                i.getIfunc().getId().accept(this);
                writer.write("(");
                //caso in cui ci sono più parametri ed inserisco la virgola
                if(i.getIfunc().getParametri().size()>1){
                    for(int j=0; j<i.getIfunc().getParametri().size()-1; j++){
                        i.getIfunc().getParametri().get(j).accept(this);
                        writer.write(", ");
                    }
                }
                //caso in cui non inserisco la virgola
                if(!i.getIfunc().getParametri().isEmpty()){
                    i.getIfunc().getParametri().get(i.getIfunc().getParametri().size()-1).accept(this);
                }
                writer.write(");\n");
                currentScope=i.getIfunc().getSymbolTableIfunc().getFather();
            }
        }

        if(program.getProcedura()!=null) {

            if (!(program.getProcedura().getId().getLessema().equals("main"))) {
                writer.write("void ");
                program.getProcedura().getId().accept(this);
                writer.write(" (");
                //caso in cui inserisco la virgola
                if (program.getProcedura().getParametri().size() > 1) {
                    for (int j = 0; j < program.getProcedura().getParametri().size() - 1; j++) {
                        program.getProcedura().getParametri().get(j).accept(this);
                        writer.write(", ");
                    }
                }
                //non inserisco la virgola
                if (program.getProcedura() != null) {
                    program.getProcedura().getParametri().get(program.getProcedura().getParametri().size() - 1).accept(this);
                }
                writer.write(");\n\n");
            }
        }

        if(program.getIterwithoutprocedure()!=null) {
            for (Iter i : program.getIterwithoutprocedure()) {
                i.accept(this);
            }
        }
        if(program.getProcedura()!=null) {
            program.getProcedura().accept(this);
        }

        if(program.getIter()!=null){
            for(Iter i: program.getIter()){
                i.accept(this);
            }
        }
        //controllo il main se esiste
        if (pMain != null) {
            pMain.accept(this);
        }

        writer.close();
        return null;
    }

    @Override
    public Object visit(Iter iter) throws Exception {

        if(iter.getFunzione()!=null) {
            iter.getFunzione().accept(this);
        }
        if(iter.getIfunc()!=null){
            iter.getIfunc().accept(this);
        }

        if(iter.getProcedura()!=null){
            SymbolTableRow proc= null;
            if(iter.getProcedura().getId().getLessema().equals("main")){
                pMain= iter.getProcedura();
            }else{
                proc= (SymbolTableRow) iter.getProcedura().accept(this);
            }
        }
        return null;
    }

    @Override
    public Object visit(Procedure procedure) throws Exception {

        currentScope= procedure.getSymbolTableProc();

         writer.write("void ");
         procedure.getId().accept(this);
         writer.write("(");

         //scrivo i parametri
        //caso in cui c'è più di un parametro, inserisco la virgola
        if(procedure.getParametri().size()>1){
            for(int i=0; i< procedure.getParametri().size()-1; i++){
                procedure.getParametri().get(i).accept(this);
                writer.write(", ");
            }
        }
        //caso in cui è l'ultimo parametro oppure singolo parametro, non inserisco la virgola
        if(procedure.getParametri()!=null&& procedure.getParametri().size()!=0){
            procedure.getParametri().get(procedure.getParametri().size()-1).accept(this);
        }
        writer.write(")");

        //corpo della procedura
        procedure.getCorpo().accept(this);

        currentScope=procedure.getSymbolTableProc().getFather();

        return null;
    }

    @Override
    public Object visit(Type type) throws Exception {

        if(type.getTipo().equals("boolean")){
            writer.write("bool");
        }
        if(type.getTipo().equals("integer")){
            writer.write("int");
        }
        if(type.getTipo().equals("real")){
            writer.write("float");
        }
        if(type.getTipo().equals("string")){
            writer.write("char*");
        }
        if(type.getTipo().equals("rgb"))
            writer.write("char*");
        return null;
    }

    @Override
    public Object visit(ProcParams procParams) throws Exception {

        procParams.getTipo().accept(this);

        writer.write(" ");

        if(procParams.getId().getAttribute()!=null && procParams.getId().getAttribute().equals("out"))
            writer.write("*");
        procParams.getId().accept(this);

        return null;
    }

    @Override
    public Object visit(ProcCall procCall) throws Exception {

        procCall.getId().accept(this);
        writer.write("(");
        if(procCall.getProcexpr().size()>1){
            for(int i=0; i<procCall.getProcexpr().size()-1; i++){
                //controllo se viene passato per riferimento
                if(procCall.getProcexpr().get(i) instanceof Identifier id && id.getAttribute()!=null && (id.getAttribute().equals("out"))){
                    writer.write("&");
                }
                procCall.getProcexpr().get(i).accept(this);
                writer.write(", ");
            }
        }
        //caso in cui è l'ultimo elemento della lista oppure singolo elemento in cui non inserisco la virgola
        if(!procCall.getProcexpr().isEmpty()){
            //controllo se viene passato per riferimento
            if(procCall.getProcexpr().get(procCall.getProcexpr().size()-1) instanceof Identifier id && id.getAttribute()!=null && (id.getAttribute().equals("out"))){
                writer.write("&");
            }
            procCall.getProcexpr().get(procCall.getProcexpr().size()-1).accept(this);
        }
        writer.write(");\n");
        return null;
    }

    @Override
    public Object visit(Function function) throws Exception {

        currentScope= function.getSymbolTableFunc();
        funId= function.getId();

        //firma della funzione
        if (function.getTipi().size()>1){
            //se la funzione restituisce più tipi, restituisco il tipo struct precedentemente cerato
            function.getId().accept(this);
            writer.write("Struct");
        } else{
            function.getTipi().get(0).accept(this);
        }
        writer.write(" ");
        function.getId().accept(this);
        writer.write("(");

        //scrivo i parametri
        //caso in cui ci sono più parametri, inserisco la virgola
        if(function.getParametri().size()>1){
            for(int i=0; i<function.getParametri().size()-1; i++){
                function.getParametri().get(i).accept(this);
                writer.write(", ");
            }
        }
        //caso in cui è l'ultimo elemento, non inserisco la virgola
        if(!function.getParametri().isEmpty()){
            function.getParametri().get(function.getParametri().size()-1).accept(this);
        }
        writer.write(")");

        //corpo della funzione
        function.getCorpo().accept(this);

        currentScope= function.getSymbolTableFunc().getFather();

        return null;
    }

    @Override
    public Object visit(FuncParams funcParams) throws Exception {

        funcParams.getTipo().accept(this);
        writer.write(" ");
        funcParams.getId().accept(this);

        return null;
    }

    @Override
    public Object visit(FunCall funCall) throws Exception {

        //accetto l'id della chiamata a funzione
        funCall.getId().accept(this);
        writer.write("(");
        //caso in cui ci sono più espressioni inserisco una virgola
        if(funCall.getExprs()!=null && funCall.getExprs().size()>1){
            for(int i=0; i<funCall.getExprs().size()-1; i++){
                funCall.getExprs().get(i).accept(this);
                writer.write(", ");
            }
        }
        //caso in cui è l'ultimo elemento oppure un singolo elemento, non inserisco la virgola
        if (funCall.getExprs()!=null){
            funCall.getExprs().get(funCall.getExprs().size()-1).accept(this);
            writer.write(")");
        }else{
            writer.write(")");
        }

        return null;
    }

    @Override
    public Object visit(DeclsOP declsOP) throws Exception {

        Iterator<Identifier> idIt= declsOP.getId().iterator();
        //inizializzazione con costanti
        if(declsOP.getTipo()==null){
            Iterator<ConstOp> conIt= declsOP.getCostanti().iterator();

            while(idIt.hasNext()&&conIt.hasNext()){
                Identifier id= idIt.next();
                ConstOp costante= conIt.next();

                if(costante.getCostante().equals("string_const")||costante.getCostante().equals("rgb")){

                    String type= convertType(costante.getCostante());

                    writer.write(type); //controllare, vedi come prenderlo automaticamente
                    writer.write(" ");
                    id.accept(this);
                    writer.write(" = malloc(MAXCHAR);\n");
                    id.accept(this);
                    writer.write(" = strncpy(");
                    id.accept(this);
                    writer.write(",");
                    costante.accept(this);
                    writer.write(", MAXCHAR)");
                }else{
                    String type = convertType(costante.getCostante());
                    //costante.accept(this);
                    writer.write(type+ " ");
                    id.accept(this);
                    writer.write(" = ");
                    costante.accept(this);
                }
                writer.write(";\n");
            }
            //inizializzazione con tipo
        }else {
            while (idIt.hasNext()){
               declsOP.getTipo().accept(this);
                writer.write(" ");
                idIt.next().accept(this);
                if(declsOP.getTipo().getTipo().equals("string")||declsOP.getTipo().getTipo().equals("rgb")){
                    //declsOP.getTipo().accept(this);

                    writer.write(" = malloc(MAXCHAR)");
                }
                writer.write(";\n");
            }
        }
        return null;
    }

    @Override
    public Object visit(Body body) throws Exception {
        writer.write("{\n");

        if (body.getVardecls() != null) {
            for (DeclsOP d : body.getVardecls()) {
                d.accept(this);
            }
        }

        Collections.reverse(body.getStatement()); //risolve problema statement al contrario

        if (body.getStatement() != null) {
            for (Statement s : body.getStatement()) {
                s.accept(this);
            }
        }

        writer.write("}\n");

        return null;
    }

    @Override
    public Object visit(AssignOP assignOP) throws Exception {
        Iterator<Identifier> idIt= assignOP.getIds().iterator();
        Iterator<Expr> exprIt= assignOP.getExprs().iterator();

        int j=0;

        while(idIt.hasNext()&&exprIt.hasNext()){
            Expr expr= exprIt.next();

            //controllo se la funzione restituisce più valori //prendo il la lista dei tipi di ritorno della funzione
            if(expr instanceof FunCall funCall && currentScope.lookup(funCall.getId().getLessema()).getType().getOutTypeList().size()>1){
                funCall.getId().accept(this);
                writer.write("Struct ");
                funCall.getId().accept(this);
                //se vengono chiamate più funzioni, la variabile j garantisce l'unicità della variabile struct
                writer.write("Returned " + j + " = ");
                funCall.accept(this);
                writer.write(";\n");

                //assegno ogni valore all'interno della struct alle rispettive variabili
                for(int i=0; i<currentScope.lookup(funCall.getId().getLessema()).getType().getOutTypeList().size(); i++){
                    Identifier id= idIt.next();

                    //controllo se è un puntatore
                    if(currentScope.lookup(id.getLessema()).getProperties() != null && currentScope.lookup(id.getLessema()).getProperties().equals("out"))
                        writer.write("*");
                    id.accept(this);
                    writer.write(" = ");
                    funCall.getId().accept(this);
                    writer.write("Returned" + j + ".value" + i);
                    writer.write(";\n");
                }
                j++;
            }
            else{
                Identifier id=idIt.next();

                if(currentScope.lookup(id.getLessema()).getProperties() != null && currentScope.lookup(id.getLessema()).getProperties().equals("out"))
                    writer.write("*");
                id.accept(this);
                writer.write(" = ");
                expr.accept(this);
                writer.write(";\n");
            }
        }
        return null;
    }

    @Override
    public Object visit(ElifOp elifOp) throws Exception {

        currentScope = elifOp.getSymbolTableElIf();

        if (elifOp.getCorpo() != null) {
            writer.write("else if(" );
            elifOp.getEspressione().accept(this);
            writer.write(")");
            elifOp.getCorpo().accept(this);
        }
        currentScope = elifOp.getSymbolTableElIf().getFather();

        return null;
    }

    @Override
    public Object visit(IfStatOp ifStatOp) throws Exception {

        writer.write("\nif(" );
        ifStatOp.getExpr().accept(this);
        writer.write(")");
        currentScope = ifStatOp.getSymbolTableIf();
        ifStatOp.getCorpo().accept(this);
        currentScope = ifStatOp.getSymbolTableIf().getFather();
        if (ifStatOp.getListelif() != null) {
            for (ElifOp le : ifStatOp.getListelif()) {
                le.accept(this);
            }
        }

        if (ifStatOp.getElseBody() != null) {
            writer.write("else");
            currentScope = ifStatOp.getSymbolTableElse();
            ifStatOp.getElseBody().accept(this);
            currentScope = ifStatOp.getSymbolTableElse().getFather();
        }
        return null;
    }

    @Override
    public Object visit(ReadOP readOP) throws Exception {

        //nel caso in caso in cui ci sono più elemnti da leggere
        if(readOP.getIoargs().size()>1){
            for(int i=0; i< readOP.getIoargs().size()-1; i++){
                if(readOP.getIoargs().get(i) instanceof Identifier id){
                    writer.write("scanf("); //inserisco uno scanf e apro la virgoletta senza chiuderla
                    SymbolType type= currentScope.lookup(id.getLessema()).getType();

                    if((type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("string")) || (type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("rgb"))){
                        writer.write("\"%s\", ");
                        readOP.getIoargs().get(i).accept(this);
                    }
                    if(type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("integer")){
                        writer.write(" \"%d\", ");
                        writer.write("&");
                        readOP.getIoargs().get(i).accept(this);
                    }
                    if(type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("real")){
                        writer.write("\"%f\", ");
                        writer.write("&");
                        readOP.getIoargs().get(i).accept(this);
                    }
                }else{
                    writer.write("printf(");
                    readOP.getIoargs().get(i).accept(this);
                }
                writer.write(");\n");
            }
            // caso in cui è l'ultimo elemento oppure singolo elemento quindi non si inserisce la virgola
            if(readOP.getIoargs()!=null){
                if(readOP.getIoargs().get(readOP.getIoargs().size()-1) instanceof Identifier id){
                    writer.write("scanf(");
                    SymbolType type= currentScope.lookup(id.getLessema()).getType();
                    if((type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("string"))|| (type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("rgb"))){
                        writer.write("\"%s\", ");
                        readOP.getIoargs().get(readOP.getIoargs().size()-1).accept(this);
                    }
                    if(type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("integer")){
                        writer.write("\"%d\", ");
                        writer.write("&");
                        readOP.getIoargs().get(readOP.getIoargs().size()-1).accept(this);
                    }
                    if(type.getInTypeList().size()!=0&&type.getInTypeList().get(0).getTipo().equals("real")){
                        writer.write("\"%f\", ");
                        writer.write("&");
                        readOP.getIoargs().get(readOP.getIoargs().size()-1).accept(this);
                    }
                }else{
                    writer.write("printf(");
                    readOP.getIoargs().get(readOP.getIoargs().size()-1).accept(this);
                }
                writer.write(");\n");
            }
        }
        return null;
    }

    @Override
    public Object visit(ReturnOP returnOP) throws Exception {

        if (returnOP.getExprs() != null) {

            //si tratta di una funzione che può restituire più valori
            if (returnOP.getExprs().size() > 1) {
                //si crea questa struttura
                writer.write(funId.getLessema());
                writer.write("Struct ");
                writer.write(funId.getLessema());
                writer.write("StructReturnValue; \n");
                for (int i = 0; i < returnOP.getExprs().size(); i++) {
                    writer.write(funId.getLessema());
                    writer.write("StructReturnValue.value" + i);
                    writer.write(" = ");
                    returnOP.getExprs().get(i).accept(this);
                    writer.write(";\n");
                }

            }
            // nel caso in cui ritorno una singola espressione
            if (returnOP.getExprs().size() == 1) {
                writer.write("return " );
                returnOP.getExprs().get(0).accept(this);
                writer.write(";\n");
            } else { //altrimenti se ritorno più espressioni ritorno il nome della funzione con la struttura
                writer.write("return ");
                writer.write(funId.getLessema());
                writer.write("StructReturnValue ");
                writer.write(";\n");
            }
        }
        return null;
    }

    @Override
    public Object visit(Statement statement) throws Exception {

        if (statement instanceof AssignOP)
            ((AssignOP) statement).accept(this);
        if (statement instanceof ProcCall)
            ((ProcCall) statement).accept(this);
        if (statement instanceof ReturnOP)
            ((ReturnOP) statement).accept(this);
        if (statement instanceof WriteOP)
            ((WriteOP) statement).accept(this);
        if (statement instanceof WriteReturnOP)
            ((WriteReturnOP) statement).accept(this);
        if (statement instanceof ReadOP)
            ((ReadOP) statement).accept(this);
        if (statement instanceof IfStatOp)
            ((IfStatOp) statement).accept(this);
        if (statement instanceof WhileOP)
            ((WhileOP) statement).accept(this);

        return null;
    }

    @Override
    public Object visit(WhileOP whileOP) throws Exception {

        currentScope = whileOP.getSymbolTable();

        writer.write("while(");
        whileOP.getEspressione().accept(this);
        writer.write(")");
        whileOP.getCorpo().accept(this);

        currentScope = whileOP.getSymbolTable().getFather();

        return null;
    }

    @Override
    public Object visit(WriteOP writeOP) throws Exception {

        //inserisco il printf senza argomenti
        writer.write("printf(\""); //apro la virgoletta ma non la chiudo
        for(int i=0; i<writeOP.getIoargs().size(); i++){
            writeOnTypes(writeOP.getIoargs().get(i));
        }
        writer.write("\", ");
        if (writeOP.getIoargs().size() > 1) { //gestiamo il caso in cui ci sono più espressioni in questo caso aggiungo una virgola
            //inserisco gli argomenti nella printf
            for (int i = 0; i < writeOP.getIoargs().size()-1; i++) {
                writeOP.getIoargs().get(i).accept(this);
                //inserisco la virgola
                writer.write(", ");
            }
        //va qui quando c'è un solo elemento oppure l'ultimo elemento della lista
        }
        if(!writeOP.getIoargs().isEmpty()){
            //inserisce l'ultimo elemento della lista oppure il singolo elemento con la virgoletta chiusa
            writeOP.getIoargs().get(0).accept(this); //lo \n inserito all'interno della printf
        }
        writer.write(");\n");
        return null;
    }

    @Override
    //vedere write op prima di scriverlo qui vedere se funziona
    public Object visit(WriteReturnOP writeReturnOP) throws Exception {

        //inserisco il printf senza argomenti
        writer.write("printf(\""); //apro la virgoletta ma non la chiudo

        for(int i=0; i<writeReturnOP.getIoargs().size(); i++){
            writeOnTypes(writeReturnOP.getIoargs().get(i));
        }
        writer.write("%s");
        writer.write("\", ");

        if (writeReturnOP.getIoargs().size() > 1) { //gestiamo il caso in cui ci sono più espressioni in questo caso aggiungo una virgola
            //inserisco gli argomenti nella printf


            //inserisco la virgola
            for (int i = 0; i < writeReturnOP.getIoargs().size() - 1; i++) {
                writeReturnOP.getIoargs().get(i).accept(this);
                writer.write(", ");
            }
        //va qui quando c'è un solo elemento oppure l'ultimo elemento della lista
        }
        if (!writeReturnOP.getIoargs().isEmpty()) {

            //inserisce l'ultimo elemento della lista oppure il singolo elemento con la virgoletta chiusa
            writeReturnOP.getIoargs().get(writeReturnOP.getIoargs().size() - 1).accept(this); //lo \n inserito all'interno della printf
            writer.write(", ");
        }
        writer.write("\"\\n\");\n");

        return null;
    }

    @Override
    public Object visit(ConstOp constOp) throws Exception {

        String costante = "";

        if (constOp.getCostante().equals("integer_const"))
            costante = constOp.getLessema();
        if (constOp.getCostante().equals("real_const"))
            costante = constOp.getLessema();
        if (constOp.getCostante().equals("string_const") || constOp.getLessema().equals("string"))
            costante = "\"" + constOp.getLessema().replace("\n", "\\n") + "\"";
        if (constOp.getCostante().equals("boolean_const"))
            costante = constOp.getLessema();
        if (constOp.getCostante().equals("rgb_const") || constOp.getLessema().equals("rgb"))
            costante = "\"" + constOp.getLessema().replace("\n", "\\n") + "\"";

        writer.write(costante);
        return costante;
    }

    @Override
    public Object visit(Expr expr) throws Exception {

        String espressione = "";
        if (expr instanceof ConstOp)
            expr.accept(this);
        if (expr instanceof Relop)
            expr.accept(this);
        if (expr instanceof Identifier)
            expr.accept(this);
        if (expr instanceof UnaryOp)
            expr.accept(this);
        if (expr instanceof FunCall)
            expr.accept(this);

        return null;
    }

    @Override
    public Object visit(Identifier identifier) throws Exception {

        if(currentScope.lookup(identifier.getLessema()) != null) {

            if (currentScope.lookup(identifier.getLessema()).getType().getInTypeList().contains("out")) {
                writer.write("*");
                writer.write(identifier.getLessema());
            } else {
                writer.write(identifier.getLessema());
            }
        }
        return null;
    }

    @Override
    public Object visit(Relop relop) throws Exception {

        String espressione = "";
        //String tipoOperazione = convertTypeOp(relop.getTipoOp());
        String tipoOperazione = String.valueOf(convertTypeOp(relop.getTipoOp()));
        //ottengo le espressioni
        //String codeExpr1 = (String) relop.getExpr1().accept(this);
        //String codeExpr2 = (String) relop.getExpr2().accept(this);

        String tipoexpr1 = relop.getExpr1().getExprType();
        String tipoexpr2 = relop.getExpr2().getExprType();

        //ottengo il tipo di operazione
        String tipoOp = relop.getTipoOp();

        if (tipoOp.equals("PlusOp")) {
            if (!tipoexpr1.contains("string") && !tipoexpr2.contains("string")) {
                relop.getExpr1().accept(this);
                writer.write(tipoOperazione);
                relop.getExpr2().accept(this);
            } else {
                //Converto le espressioni in stringhe se sono di altro tipo
                writer.write("str_concat(");

                if(relop.getExpr1().getExprType().contains("string")&& relop.getExpr2().getExprType().contains("string")){
                    relop.getExpr1().accept(this);
                    writer.write(",");
                    relop.getExpr2().accept(this);
                }

                if(relop.getExpr1().getExprType().contains("integer")&&relop.getExpr2().getExprType().contains("string")){
                    writer.write("integer_to_str(");
                    relop.getExpr1().accept(this);
                    writer.write("),");
                    relop.getExpr2().accept(this);
                }

                if(relop.getExpr1().getExprType().contains("string")&&relop.getExpr2().getExprType().contains("integer")){
                    relop.getExpr1().accept(this);
                    writer.write(",");
                    writer.write("integer_to_str(");
                    relop.getExpr2().accept(this);
                    writer.write(")");
                }

                if(relop.getExpr1().getExprType().contains("real")&&relop.getExpr2().getExprType().contains("string")){
                    writer.write("real_to_str(");
                    relop.getExpr1().accept(this);
                    writer.write("),");
                    relop.getExpr2().accept(this);
                }

                if(relop.getExpr1().getExprType().contains("string")&&relop.getExpr2().getExprType().contains("real")){
                    relop.getExpr1().accept(this);
                    writer.write(",");
                    writer.write("real_to_str(");
                    relop.getExpr2().accept(this);
                    writer.write(")");
                }

                if(relop.getExpr1().getExprType().contains("boolean")&&relop.getExpr2().getExprType().contains("string")){
                    writer.write("bool_to_str(");
                    relop.getExpr1().accept(this);
                    writer.write("),");
                    relop.getExpr2().accept(this);
                }

                if(relop.getExpr1().getExprType().contains("string")&&relop.getExpr2().getExprType().contains("boolean")){
                    relop.getExpr1().accept(this);
                    writer.write(",");
                    writer.write("bool_to_str(");
                    relop.getExpr2().accept(this);
                    writer.write(")");
                }

                if(relop.getExpr1().getExprType().contains("rgb")&& relop.getExpr2().getExprType().contains("string")){
                    relop.getExpr1().accept(this);
                    writer.write(",");
                    relop.getExpr2().accept(this);
                }
                if(relop.getExpr1().getExprType().contains("string")&& relop.getExpr2().getExprType().contains("rgb")){
                    relop.getExpr1().accept(this);
                    writer.write(",");
                    relop.getExpr2().accept(this);
                }


                writer.write(")");

            }
        }
        //operazioni aritmetiche
        if (tipoOp.equals("DivOp") || tipoOp.equals("MinusOp") || tipoOp.equals("TimesOp")) {
            relop.getExpr1().accept(this);
            writer.write(tipoOperazione);
            relop.getExpr2().accept(this);
        }
        //operazioni relazionali
        if (tipoOp.equals("GTOp") || tipoOp.equals("GEOp") || tipoOp.equals("LTOp") || tipoOp.equals("LEOp") || tipoOp.equals("EQOp") || tipoOp.equals("NEOp")) {
            if (tipoOp.equals("EQOp") && (tipoexpr1.contains("string") || tipoexpr2.contains("string"))) {
                writer.write( "strcmp(");
                relop.getExpr1().accept(this);
                writer.write( ",");
                relop.getExpr2().accept(this);
                writer.write( ") == 0");
            }else if (tipoOp.equals("NEOp") && (tipoexpr1.contains("string") || tipoexpr2.contains("string"))) {
                writer.write( "strcmp(");
                relop.getExpr1().accept(this);
                writer.write( ",");
                relop.getExpr2().accept(this);
                writer.write( ")!=0");
            }else{
                relop.getExpr1().accept(this);
                writer.write(tipoOperazione);
                relop.getExpr2().accept(this);
            }
        }

        if (tipoOp.equals("AndOp") || tipoOp.equals("OrOp")) {
            relop.getExpr1().accept(this);
            writer.write(tipoOperazione);
            relop.getExpr2().accept(this);
        }

        return null;
    }

    @Override
    public Object visit(UnaryOp unaryOp) throws Exception {

        String espressione = "";
        //ottengo l'espressione
        String expr1 = (String) unaryOp.getExpr().accept(this);
        String typeOp = unaryOp.getExprType();
        String operazione = convertType(typeOp);

        if (typeOp.equals("UminusOp") || typeOp.equals("NotOp")) {
            espressione = operazione + "(" + expr1 + ")";
        }

        return espressione;
    }

    @Override
    public Object visit(IfuncOP ifuncOP) throws Exception {

        currentScope= ifuncOP.getSymbolTableIfunc();
        funId= ifuncOP.getId();

        //firma della funzione

        writer.write("int");

        writer.write(" ");
        ifuncOP.getId().accept(this);
        writer.write("(");

        //scrivo i parametri
        //caso in cui ci sono più parametri, inserisco la virgola
        if(ifuncOP.getParametri().size()>1){
            for(int i=0; i<ifuncOP.getParametri().size()-1; i++){
                ifuncOP.getParametri().get(i).accept(this);
                writer.write(", ");
            }
        }
        //caso in cui è l'ultimo elemento, non inserisco la virgola
        if(!ifuncOP.getParametri().isEmpty()){
            ifuncOP.getParametri().get(ifuncOP.getParametri().size()-1).accept(this);
        }
        writer.write(")");

        //corpo della funzione
        ifuncOP.getBodyIfunc().accept(this);

        currentScope= ifuncOP.getSymbolTableIfunc().getFather();

        return null;
    }

    //conversione tipi per C
    public String convertType(String type) {
        if (type.equals("integer")) type = "int";
        if (type.equals("integer_const")) type = "int";
        if (type.equals("boolean")) type = "bool";
        if (type.equals("boolean_const")) type = "bool";
        if (type.equals("string")) type = "char*";
        if (type.equals("string_const")) type = "char*";
        if (type.equals("real")) type = "float";
        if (type.equals("real_const")) type = "float";
        if (type.equals("rgb_const")) type="char*";
        if (type.equals("rgb")) type="char*";
        return type;
    }

    //conversione del tipo di operazione in C
    public String convertTypeOp(String typeOp) {

        String tipoOprazione = "";
        if (typeOp.equals("PlusOp")) //addizione
            tipoOprazione = "+";
        if (typeOp.equals("MinusOp")) //sottrazione
            tipoOprazione = "-";
        if (typeOp.equals("TimesOp")) //moltiplicazione
            tipoOprazione = "*";
        if (typeOp.equals("DivOp")) //divisione
            tipoOprazione = "/";
        if (typeOp.equals("GTOp")) //maggiore
            tipoOprazione = ">";
        if (typeOp.equals("GEOp")) //maggiore uguale
            tipoOprazione = ">=";
        if (typeOp.equals("LTOp")) //minore
            tipoOprazione = "<";
        if (typeOp.equals("LEOp")) //minore uguale
            tipoOprazione = "<=";
        if (typeOp.equals("NEOp")) //diverso
            tipoOprazione = "!=";
        if (typeOp.equals("EQOp")) //uguaglianza
            tipoOprazione = "==";
        if (typeOp.equals("AndOp")) //and
            tipoOprazione = "&&";
        if (typeOp.equals("OrOp")) //or
            tipoOprazione = "||";
        if (typeOp.equals("UminusOp")) //meno davanti un espressione
            tipoOprazione = "-1*";
        if (typeOp.equals("NotOp")) //negazione davanti un espressione
            tipoOprazione = "!";

        return tipoOprazione;
    }

    private ArrayList<String> getFunTypes(FunCall funCall) {
        SymbolTable temp = currentScope;
        ArrayList<String> returnTypes = new ArrayList<String>();
        while (currentScope != null) {
            SymbolTableRow result = currentScope.lookup(funCall.getId().getLessema());

            if (result != null) {
                SymbolType type = result.getType();
                for (Type t : type.getOutTypeList()) {
                    returnTypes.add(t.getTipo());
                }
            } else {
                currentScope = currentScope.getFather();
            }
        }

        return returnTypes;
    }

    //funzione che permette di formattare i tipi della printf
    private void writeOnTypes(Expr expr) throws Exception {
        String nametype;
        TypeVisitor typeVisitor= new TypeVisitor();
        typeVisitor.currentScope= currentScope;
        if(expr instanceof ConstOp constop)
            nametype= constop.getCostante();
        else if(expr instanceof Identifier id)
            nametype= currentScope.lookup(id.getLessema()).getType().getInTypeList().get(0).getTipo();
        else if(expr instanceof FunCall funCall)
            nametype= currentScope.lookup(funCall.getId().getLessema()).getType().getOutTypeList().get(0).getTipo();
        else if (expr instanceof Relop relop) {
            SymbolType symbolType= (SymbolType) typeVisitor.visit(relop);
            nametype= symbolType.getInTypeList().get(0).getTipo();
        }  else if (expr instanceof UnaryOp unaryOp) {
            SymbolType symbolType= (SymbolType) typeVisitor.visit(unaryOp);
            nametype= symbolType.getInTypeList().get(0).getTipo();
        }else{
            throw new Exception("Espressione non valida");
        }

        if(nametype.contains("string"))
            writer.write("%s ");
        if(nametype.contains("rgb"))
            writer.write("%s");
        if(nametype.contains("boolean")||nametype.contains("integer"))
            writer.write("%d ");
        if(nametype.contains("real"))
            writer.write("%f ");
    }

    //funzioni di utilità
    public void addHelperFunctions() throws IOException {
        writer.write("char* integer_to_str(int i){\n");
        writer.write("int length= snprintf(NULL,0,\"%d\",i);\n");
        writer.write("char* result=malloc(length+1);\n");
        writer.write("snprintf(result,length+1,\"%d\",i);\n");
        writer.write("return result;\n");
        writer.write("}\n");

        writer.write("char* real_to_str(float i){\n");
        writer.write("int length= snprintf(NULL,0,\"%f\",i);\n");
        writer.write("char* result=malloc(length+1);\n");
        writer.write("snprintf(result,length+1,\"%f\",i);\n");
        writer.write("return result;\n");
        writer.write("}\n");

        writer.write("char* bool_to_str(bool i){\n");
        writer.write("int length= snprintf(NULL,0,\"%d\",i);\n");
        writer.write("char* result=malloc(length+1);\n");
        writer.write("snprintf(result,length+1,\"%d\",i);\n");
        writer.write("return result;\n");
        writer.write("}\n");

        writer.write("char* str_concat(char* str1, char* str2){\n");
        writer.write("char* result=malloc(sizeof(char)*MAXCHAR);\n");
        writer.write("result=strcat(result,str1);\n");
        writer.write("result=strcat(result,str2);\n");
        writer.write("return result;");
        writer.write("}\n");

        writer.write("\n");
        writer.write("char* read_str(){\n");
        writer.write("char* str=malloc(sizeof(char)*MAXCHAR);\n");
        writer.write("scanf(\"%s\",str);\n");
        writer.write("return str;");
        writer.write("}\n");

    }
    public void addBaseLibraries() throws IOException {
        writer.write("#include <stdio.h>\n");
        writer.write("#include <stdlib.h>\n");
        writer.write("#include <string.h>\n");
        writer.write("#include <math.h>\n");
        writer.write("#include <unistd.h>\n");
        writer.write("#include <stdbool.h>\n");
        writer.write("#define MAXCHAR 512\n");
    }
}
