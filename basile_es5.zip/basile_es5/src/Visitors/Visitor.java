package Visitors;

import node.*;
import node.Expr.*;
import node.statement.*;

public interface Visitor {

    public Object visit(Program program)throws Exception;
    public Object visit(Iter iter) throws Exception;
    public Object visit(Procedure procedure) throws Exception;
    public Object visit(Type type) throws Exception;
    public Object visit(ProcParams procParams) throws Exception;
    public Object visit(ProcCall procCall) throws Exception;
    public Object visit(Function function) throws Exception;
    public Object visit(FuncParams funcParams) throws Exception;
    public Object visit(FunCall funCall) throws Exception;
    public Object visit(DeclsOP declsOP) throws Exception;
    public Object visit(Body body) throws Exception;
    public Object visit(AssignOP assignOP) throws Exception;
    public Object visit(ElifOp elifOp) throws Exception;
    public Object visit(IfStatOp ifStatOp) throws Exception;
    public Object visit(ReadOP readOP) throws Exception;
    public Object visit(ReturnOP returnOP) throws Exception;
    public Object visit(Statement statement) throws Exception;
    public Object visit(WhileOP whileOP) throws Exception;
    public Object visit(WriteOP writeOP) throws Exception;
    public Object visit(WriteReturnOP writeReturnOP) throws Exception;
    public Object visit(ConstOp constOp) throws Exception;
    public Object visit(Expr expr) throws Exception;
    public Object visit(Identifier identifier) throws Exception;
    public Object visit(Relop relop) throws Exception;
    public Object visit(UnaryOp unaryOp) throws Exception;

    //modifica
    public Object visit(IfuncOP ifuncOP) throws Exception;
}
