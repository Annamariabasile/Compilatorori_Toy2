package Visitors;

import SymbolTable.*;
import node.*;
import node.Expr.*;
import node.statement.*;
import utils.Exceptions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import utils.Exceptions;

public class SemanticVisitorScope implements Visitor {
    private SymbolTable padre = null;

    //genero lo scope della root, inserendo variabili e funzioni
    @Override
    public Object visit(Program program) throws Exception {
        program.setSymbolTable(new SymbolTable());
        SymbolTable symbolTable = program.getSymbolTable();
        symbolTable.setScope("Root");
        symbolTable.setFather(null);
        padre = symbolTable;
        ////System.out.println(symbolTable.getScope());
        //Se sono presenti iterazioni senza procedure le aggiungo allo scope
        if (program.getIterwithoutprocedure() != null) {
            for (Iter iter : program.getIterwithoutprocedure()) {
                iter.accept(this);
            }
        }

        // se sono presenti procedure
        if (program.getProcedura() != null) {

            ArrayList<Type> inTypes = new ArrayList<Type>();
            ArrayList<Type> outTypes = new ArrayList<Type>();
            for (ProcParams param : program.getProcedura().getParametri()) {
                    inTypes.add(param.getTipo());
            }
            padre.addRow(new SymbolTableRow(program.getProcedura().getId().getLessema(), "Proc", new SymbolType(inTypes, outTypes), ""));
            program.getProcedura().accept(this);
        }
        //se sono presenti degli iter
        if (program.getIter() != null) {
            for (Iter iter : program.getIter()) {
                iter.accept(this);
            }
        }
        System.out.println(padre);
        return null;
    }

    @Override
    public Object visit(Iter iter) throws Exception {

        if (iter.getVariabili() != null) {
            ArrayList<SymbolTableRow> variabili = new ArrayList<>();
            for (DeclsOP d : iter.getVariabili()) {
                d.accept(this);
            }
        }
        if (iter.getProcedura() != null) {

            ArrayList<Type> inTypes = new ArrayList<Type>();
            ArrayList<Type> outTypes = new ArrayList<Type>();
            for (ProcParams param : iter.getProcedura().getParametri()) {
                inTypes.add(param.getTipo());
            }

            padre.addRow(new SymbolTableRow(iter.getProcedura().getId().getLessema(), "Proc", new SymbolType(inTypes, outTypes), ""));
            iter.getProcedura().accept(this);

        }
        if (iter.getFunzione() != null) {

            ArrayList<Type> inTypes = new ArrayList<Type>();
            ArrayList<Type> outTypes = new ArrayList<Type>();
            //aggiungo i parametri nella lista di intypes
            for (FuncParams paramFunc : iter.getFunzione().getParametri()) {
              inTypes.add(paramFunc.getTipo());
            }
            //outTypes = iter.getFunzione().getTipi();

            //aggiungo i tipi di ritorno alla lista outypes
            for(Type typeReturnFunc: iter.getFunzione().getTipi()){
                outTypes.add(typeReturnFunc);
            }

            padre.addRow(new SymbolTableRow(iter.getFunzione().getId().getLessema(), "func", new SymbolType(inTypes, outTypes), ""));

            iter.getFunzione().accept(this);
           // SymbolTableRow functions = (SymbolTableRow) iter.getFunzione().accept(this);
            // padre.addRow(functions);
        }

        if (iter.getIfunc() != null) {

            ArrayList<Type> inTypes = new ArrayList<Type>();
            ArrayList<Type> outTypes = new ArrayList<Type>();
            //aggiungo i parametri nella lista di intypes
            for (FuncParams paramFunc : iter.getIfunc().getParametri()) {
                inTypes.add(paramFunc.getTipo());
            }

            //aggiungo i tipi di ritorno alla lista outypes
            Type typeIfunc = new Type("integer");
            outTypes.add(typeIfunc);


            padre.addRow(new SymbolTableRow(iter.getIfunc().getId().getLessema(), "func", new SymbolType(inTypes, outTypes), ""));

            iter.getIfunc().accept(this);
            // SymbolTableRow functions = (SymbolTableRow) iter.getFunzione().accept(this);
            // padre.addRow(functions);
        }


        return null;
    }

    @Override
    public Object visit(Procedure procedure) throws Exception {

        procedure.setSymbolTableProc(new SymbolTable());
        SymbolTable symbolTableProc = procedure.getSymbolTableProc();
        symbolTableProc.setScope(procedure.getId().getLessema()); //prendo il nome della procedura
        symbolTableProc.setFather(padre);

        //se non esiste la tabella la creo
        if (procedure.getSymbolTableProc() == null) {
            procedure.setSymbolTableProc(symbolTableProc);

        }
        //inserisco i parametri della procedura nella tabella dei simboli
        for (ProcParams params : procedure.getParametri()) {
            procedure.getSymbolTableProc().addRow(new SymbolTableRow(params.getId().getLessema(), "Param", new SymbolType(params.getTipo()), params.getId().getAttribute()));
        }

        //setto il padre a procedura cosi body può utilizzare lo stesso padre
        padre = procedure.getSymbolTableProc();
        //System.out.println(procedure.getId().getLessema());
        procedure.getCorpo().accept(this);

        //System.out.println(padre);
        //System.out.println("Sono in procedura");

        //risetto il padre a prima di procedura
        padre = symbolTableProc.getFather();

        return null;
    }

    @Override
    public Object visit(Type type) throws Exception {
        return type.getTipo();
    }

    @Override
    public Object visit(ProcParams procParams) throws Exception {
        ArrayList<SymbolTableRow> tablerow = new ArrayList<>();
        if (procParams != null) {
            SymbolTableRow Tr = new SymbolTableRow(procParams.getId().getLessema(), "var", new SymbolType(procParams.getTipo()), procParams.getId().getAttribute());
            tablerow.add(Tr);
        }
        return tablerow;
    }

    @Override
    public Object visit(ProcCall procCall) throws Exception {
        if (procCall.getProcexpr() != null) {
            for (Expr e : procCall.getProcexpr()) {
                //System.out.println(procCall.getId().getLessema() + " " + e.getEspressione());
                e.accept(this);
            }
        }
        return null;
    }

    @Override
    public Object visit(Function function) throws Exception {
        function.setSymbolTableFunc(new SymbolTable());
        SymbolTable symbolTableFunc = function.getSymbolTableFunc(); //creo la tabella per function
        symbolTableFunc.setScope("Function:" + function.getId().getLessema());
        symbolTableFunc.setFather(padre);

        padre = symbolTableFunc;

        //se non esiste la tabella la creo
        if (function.getSymbolTableFunc() == null) {
            function.setSymbolTableFunc(symbolTableFunc);

        }
        //inserisco i parametri della funzione nella tabella dei simboli

        if (function.getParametri() != null) {
            for (FuncParams params : function.getParametri()) {
                ArrayList<SymbolTableRow> ParamsFunc = (ArrayList<SymbolTableRow>) params.accept(this);
                for (SymbolTableRow symbolTableRow : ParamsFunc)
                    symbolTableFunc.addRow(symbolTableRow);
                //function.getSymbolTableFunc().addRow(new SymbolTableRow(params.getId().getLessema(), "Param", new SymbolType(params.getTipo()), ""));
            }
        }
        //System.out.println("Sono in funzione"); //stampo la tabella
        //System.out.println(padre); //stampo la tabella
        //setto il padre a funzione cosi body può utilizzare lo stesso padre
        padre = function.getSymbolTableFunc();

        function.getCorpo().accept(this);

        //risetto il padre a prima di funzione
        padre = symbolTableFunc.getFather();

        return null;
    }

    @Override
    public Object visit(FuncParams funcParams) throws Exception {
        ArrayList<SymbolTableRow> tablerow = new ArrayList<>();
        if (funcParams != null) {
            SymbolTableRow Tr = new SymbolTableRow(funcParams.getId().getLessema(), "var", new SymbolType(funcParams.getTipo()), "immutable");
            tablerow.add(Tr);
        }
        return tablerow;
    }

    @Override
    public Object visit(FunCall funCall) throws Exception {
        if (funCall.getExprs() != null) {
            for (Expr e : funCall.getExprs())
                e.accept(this);
        }
        return null;
    }

    @Override
    public Object visit(DeclsOP declsOP) throws Exception {

        ArrayList<Identifier> ids = declsOP.getId();
        ArrayList<ConstOp> consts = declsOP.getCostanti();

        if (declsOP.getTipo() != null) { //se c'è il tipo non ci sono le costanti
            Type type = declsOP.getTipo();
            for (Identifier id : ids) {
                padre.addRow(new SymbolTableRow(id.getLessema(), "var", new SymbolType(type), ""));
            }
        } else { //se non c'è il tipo ci sono le costanti

            Iterator<Identifier> idsIter = ids.iterator();
            Iterator<ConstOp> constsIter = consts.iterator();

            while (idsIter.hasNext() && constsIter.hasNext()) {

                //prendo il tipo di const

                Type typeConst = new Type((String) constsIter.next().accept(this));


                //creo una nuova riga e gli passo l'id, il var, il tipo della costante, e le proprietà che sono vuote
                padre.addRow(new SymbolTableRow(idsIter.next().getLessema(), "var", new SymbolType(typeConst), ""));

            }

        }
        return null;
    }

    @Override
    public Object visit(Body body) throws Exception {
        //controllo sulla lista di vardecl
        if (body.getVardecls() != null) {
            ArrayList<SymbolTableRow> listaVar;
            for (DeclsOP var : body.getVardecls()) {
                var.accept(this);
            }
        }

        //controllo sulla lista degli statment
        if (body.getStatement() != null) {
            for (Statement stmt : body.getStatement()) {
                if (stmt instanceof WhileOP)
                    //genero lo scope del while
                    ((WhileOP) stmt).accept(this);
                if (stmt instanceof IfStatOp)
                    //genero lo scope dell'if
                    ((IfStatOp) stmt).accept(this);
                if(stmt instanceof ProcCall)
                    ((ProcCall)stmt).accept(this);
            }
        }

        return null;
    }

    @Override
    public Object visit(AssignOP assignOP) throws Exception {

        //accetto gli id
        for (Expr assignOpId : assignOP.getIds())
            assignOpId.accept(this);

        //accetto le espressioni
        for (Expr assignOp : assignOP.getExprs())
            assignOp.accept(this);

        return null;
    }

    @Override
    public Object visit(ElifOp elifOp) throws Exception {
        elifOp.setSymbolTableElIf(new SymbolTable());
        SymbolTable symbolTableElIf = elifOp.getSymbolTableElIf();
        symbolTableElIf.setScope("ElIf");
        symbolTableElIf.setFather(padre);

        padre = symbolTableElIf;

        if (elifOp.getCorpo() != null)
            elifOp.getCorpo().accept(this);

        elifOp.getEspressione().accept(this);

        //resetto la tabella "padre" (che è quella su cui si fanno i controlli) in modo che
        //quando restituisce il controllo alla funzione che ha chiamato questa
        //la tabella analizzata sia quella che c'era prima di fare questa nuova

        //System.out.println("sono nell'else if"); //stampo la tabella
        //System.out.println(padre); //stampo la tabella

        padre = symbolTableElIf.getFather();

        //System.out.println(padre); //stampo la tabella

        return null;
    }

    @Override
    public Object visit(IfStatOp ifStatOp) throws Exception {

        //tabella if
        ifStatOp.setSymbolTableIf(new SymbolTable());
        SymbolTable symbolTableIf = ifStatOp.getSymbolTableIf();
        symbolTableIf.setScope("If");
        symbolTableIf.setFather(padre);

        padre = symbolTableIf;

        ifStatOp.getExpr().accept(this);

        ifStatOp.getCorpo().accept(this);

        //System.out.println("sono nell'if");
        //System.out.println(padre);

        //si setta la tabella dell'if al padre precedente di if
        padre = symbolTableIf.getFather();

        if(ifStatOp.getListelif()!=null) {
            for (ElifOp elif : ifStatOp.getListelif())
                elif.accept(this);
        }
        //tabella else
        ifStatOp.setSymbolTableElse(new SymbolTable());
        SymbolTable symbolTableElse = ifStatOp.getSymbolTableElse();
        symbolTableElse.setScope("Else");
        symbolTableElse.setFather(padre);

        padre = symbolTableElse;

        if (ifStatOp.getElseBody() != null)
            ifStatOp.getElseBody().accept(this);

        //System.out.println("Sono in else"); //stampo la tabella
        //System.out.println(padre); //stampo la tabella
        padre = symbolTableIf.getFather();

        return null;

    }

    @Override
    public Object visit(ReadOP readOP) throws Exception {

        for (Expr readOp : readOP.getIoargs())
            readOp.accept(this);
        return null;
    }

    @Override
    public Object visit(ReturnOP returnOP) throws Exception {

        for (Expr returnOp : returnOP.getExprs())
            returnOp.accept(this);
        return null;
    }

    @Override
    public Object visit(Statement statement) throws Exception {
        return null;
    }

    //genero la symbol table per il while
    @Override
    public Object visit(WhileOP whileOP) throws Exception {

        whileOP.setSymbolTable(new SymbolTable());
        SymbolTable symbolTable = whileOP.getSymbolTable();
        symbolTable.setScope("While");
        symbolTable.setFather(padre);

        whileOP.getEspressione().accept(this);
        if (whileOP.getCorpo() != null) {
            padre = whileOP.getSymbolTable();
            whileOP.getCorpo().accept(this);
        }

        //ritorno al padre precedente del while
        padre = whileOP.getSymbolTable().getFather();
        return null;
    }

    @Override
    public Object visit(WriteOP writeOP) throws Exception {
        for (Expr writeOp : writeOP.getIoargs())
            writeOp.accept(this);
        return null;
    }

    @Override
    public Object visit(WriteReturnOP writeReturnOP) throws Exception {
        for (Expr writeReturnOp : writeReturnOP.getIoargs())
            writeReturnOp.accept(this);
        return null;
    }

    @Override
    public Object visit(ConstOp constOp) throws Exception {
        String type = constOp.getCostante();
        if (type.equals("real_const"))
            return "real";
        if (type.equals("integer_const"))
            return "integer";
        if (type.equals("string_const"))
            return "string";
        if (type.equals("boolean_const"))
            return "boolean";
        return null;
    }

    @Override
    public Object visit(Expr expr) throws Exception {
        if (expr instanceof ConstOp) //controlliamo se l'expr usatati sia del tipo di ConstOp
            ((ConstOp) expr).accept(this); //accetto l'espressione del tipo ConstOp
        if (expr instanceof Relop)
            ((Relop) expr).accept(this);
        if (expr instanceof FunCall)
            ((FunCall) expr).accept(this);
        if (expr instanceof UnaryOp)
            ((UnaryOp) expr).accept(this);
        if (expr instanceof Identifier)
            ((Identifier) expr).accept(this);
        return null;
    }

    @Override
    public Object visit(Identifier identifier) throws Exception {

        if (padre.lookup(identifier.getLessema()) == null)
            throw new Exceptions.NoDeclarationError("variabile", identifier.getLessema());

        return null;
    }

    @Override
    public Object visit(Relop relop) throws Exception {
        relop.getExpr1().accept(this);
        relop.getExpr2().accept(this);
        return null;
    }

    @Override
    public Object visit(UnaryOp unaryOp) throws Exception {
        unaryOp.getExpr().accept(this);
        return null;
    }

    @Override
    public Object visit(IfuncOP ifuncOP) throws Exception {


        ifuncOP.setSymbolTableIfunc(new SymbolTable());
        SymbolTable symbolTableIfunc = ifuncOP.getSymbolTableIfunc(); //creo la tabella per function
        symbolTableIfunc.setScope("Function:" + ifuncOP.getId().getLessema());
        symbolTableIfunc.setFather(padre);

        padre = symbolTableIfunc;

        //se non esiste la tabella la creo
        if (ifuncOP.getSymbolTableIfunc() == null) {
            ifuncOP.setSymbolTableIfunc(symbolTableIfunc);

        }
        //inserisco i parametri della funzione nella tabella dei simboli

        if (ifuncOP.getParametri() != null) {
            for (FuncParams params : ifuncOP.getParametri()) {
                ArrayList<SymbolTableRow> ParamsIFunc = (ArrayList<SymbolTableRow>) params.accept(this);
                for (SymbolTableRow symbolTableRow : ParamsIFunc)
                    symbolTableIfunc.addRow(symbolTableRow);
            }
        }
        //System.out.println("Sono in I funzione"); //stampo la tabella
        //System.out.println(padre); //stampo la tabella
        //setto il padre a funzione cosi body può utilizzare lo stesso padre
        padre = ifuncOP.getSymbolTableIfunc();

        ifuncOP.getBodyIfunc().accept(this);
        System.out.println(padre);

        //risetto il padre a prima di funzione
        padre = symbolTableIfunc.getFather();

        return null;
    }
}
