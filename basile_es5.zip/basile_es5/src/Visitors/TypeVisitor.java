package Visitors;

import SymbolTable.*;
import node.*;
import node.Expr.*;
import node.statement.*;
import utils.Exceptions;

import java.util.ArrayList;
import java.util.Iterator;

public class TypeVisitor implements Visitor {


    static SymbolTable currentScope;

    //combinazioni meno
    private static final String[][] combinazioniMinus = {{"integer", "integer"},
            {"real", "real"}};

    //combinazioni del not
    private static final String[][] combinazioniNot = {{"boolean", "boolean"}};


    //combinazioni aritmetiche
    private static final String[][] combinazioniAritmetiche = {{"integer", "integer", "integer"},
            {"integer", "real", "real"},
            {"real", "integer", "real"},
            {"real", "real", "real"}};

    // combinazione concatenazioni
    private static final String[][] combinazioneConcat = {{"string", "string", "string"},
            {"string", "integer", "string"},
            {"integer", "string", "string"},
            {"string", "real", "string"},
            {"real", "string", "string"},
            {"string", "boolean", "string"},
            {"boolean", "string", "string"},
            {"rgb", "string", "string"},
            {"string", "rgb", "string"}};


    //combinazione booleana
    private static final String[][] combinazioniBoolean = {{"boolean", "boolean", "boolean"}};


    //combinazioni tra le espressioni(relazioni)
    private static final String[][] combinazioniRelOp = {{"integer", "integer", "boolean"},
            {"real", "real", "boolean"},
            {"real", "integer", "boolean"},
            {"integer", "real", "boolean"},
            {"string", "string", "boolean"},
            {"boolean", "boolean", "boolean"},
            {"rgb", "string", "boolean"},
            {"string", "rgb","boolean"},
            {"rgb", "rgb", "boolean"}


    };

    @Override
    public Object visit(Program program) throws Exception {
        currentScope = program.getSymbolTable();

        if (program.getIterwithoutprocedure().size() > 0) {
            for (Iter i : program.getIterwithoutprocedure()) {
                SymbolTableRow iterList = (SymbolTableRow) i.accept(this);
            }
        }

        if (program.getProcedura() != null) {
            SymbolTableRow proc = (SymbolTableRow) program.getProcedura().accept(this);
            if (program.getProcedura().getId().getLessema().equals("main")) {
                check = true;
            }
        }

        if (program.getIter().size() > 0) {
            for (Iter i : program.getIter()) {
                SymbolTableRow iterList = (SymbolTableRow) i.accept(this);
            }
        }

        //controllo che ci sia una procedura che si chiama main
        if (!check) {
            throw new Exception("Non c'è un main nel programma!");
        }
        return null;
    }

    boolean check = false;

    @Override
    public Object visit(Iter iter) throws Exception {

        //dichiarazioni vardecl
        if (iter.getVariabili() != null) {
            ArrayList<SymbolTableRow> varList = new ArrayList<>();
            for (DeclsOP d : iter.getVariabili()) {
                varList = (ArrayList<SymbolTableRow>) d.accept(this);
            }
        }

        //funzioni
        if (iter.getFunzione() != null) {
            iter.getFunzione().accept(this);
        }

        if(iter.getIfunc()!=null){
            iter.getIfunc().accept(this);
        }

        //procedura
        if (iter.getProcedura() != null) {
            SymbolTableRow proc = (SymbolTableRow) iter.getProcedura().accept(this);
            //controlliamo che ci sia una procedura che si chiami main
            if (iter.getProcedura().getId().getLessema().equals("main")) {
                check = true;
            }
        }
        return null;
    }

    @Override
    public Object visit(Procedure procedure) throws Exception {
        currentScope = procedure.getSymbolTableProc();

        if (checkReturnProc(procedure.getCorpo()))
            throw new RuntimeException("Procedura: " + procedure.getId().getLessema() + " non può avere return");

        currentScope = procedure.getSymbolTableProc();
        procedure.getCorpo().accept(this);
        return null;
    }

    public boolean checkReturnProc(Body body) {
        boolean flag = false;
        for (Statement s : body.getStatement()) {
            if (s instanceof ReturnOP) {
                flag = true;
            } else if (s instanceof IfStatOp) {
                IfStatOp ifStatOp = (IfStatOp) s;
                boolean elifFlag = false;

                if (ifStatOp.getListelif() != null) {
                    for (ElifOp elifOp : ifStatOp.getListelif()) {
                        if (checkReturnProc(elifOp.getCorpo())) {
                            elifFlag = true;
                            break;
                        }
                    }
                }
                flag = flag || checkReturnProc(ifStatOp.getCorpo()) || checkReturnProc(ifStatOp.getElseBody()) || elifFlag;
            } else if (s instanceof WhileOP) {
                WhileOP whileOP = (WhileOP) s;
                flag = flag || checkReturnProc(whileOP.getCorpo());
            }
        }
        return flag;
    }

    @Override
    public Object visit(Type type) throws Exception {
        return type.getTipo();
    }

    @Override
    public Object visit(ProcParams procParams) throws Exception {
        return null;
    }

    @Override
    public Object visit(ProcCall procCall) throws Exception {

        SymbolType symbolType = (SymbolType) procCall.getId().accept(this);
        //System.out.println(symbolType);
        //iteratore tipi di controllo
        Iterator<Type> typeIterIn = symbolType.getInTypeList().iterator();

        //controllo che ogni parametro abbia lo stesso tipo del rispettivo parametro della firma
        for (int i = 0; i < procCall.getProcexpr().size(); i++) {

            Expr expr = procCall.getProcexpr().get(i);

            SymbolType symbolTypeProcCall = (SymbolType) expr.accept(this);
            if (expr instanceof FunCall && symbolTypeProcCall.getInTypeList().size() != 1) {
                throw new Exception("La chiamata a funzione non può essere passata come argomento poichè resituisce più valori");
            }

            //controllo nella tabella dei simboli della procedura se i parametri vengono passati nel giusto modo
            for (int p = 0; p < procCall.getRoot().getChildCount(); p++) {
                if (procCall.getRoot().getChildAt(p) instanceof Procedure procedure && procedure.getId().getLessema().equals(procCall.getId().getLessema())) {
                    if (expr instanceof Identifier id) {
                        if ((id.getAttribute() == null || !id.getAttribute().equals("out")) && procedure.getParametri().get(i).getId().getAttribute() != null && procedure.getParametri().get(i).getId().getAttribute().equals("out")) {
                            throw new Exception("Id: " + id.getLessema() + " deve essere passato per riferimento");
                        } else if (id.getAttribute() != null && id.getAttribute().equals("out") && (procedure.getParametri().get(i).getId().getAttribute() == null || !procedure.getParametri().get(i).getId().getAttribute().equals("out"))) {
                            throw new Exception("L'id: " + id.getLessema() + " non deve essere passato per riferimento");
                        }
                    }
                }
            }

            Iterator<Type> typeProcCallOut = symbolTypeProcCall.getInTypeList().iterator();
            //System.out.println(symbolTypeProcCall);
            //System.out.println("procout: " + symbolTypeProcCall.getInTypeList().size());
            //System.out.println("typeiter: " + symbolType.getInTypeList().size());

            while (typeProcCallOut.hasNext() && typeIterIn.hasNext()) {
                Type procCallType = typeProcCallOut.next();
                Type type = typeIterIn.next();
                //controlliamo che i tipi combacino
                if (!procCallType.getTipo().equals(type.getTipo())) {
                    throw new Exception("La chiamata a procedura: " + procCall.getId().getLessema() + ". Il tipo: " + procCallType.getTipo() + " non combacia con il tipo " + type.getTipo());
                }
            }
            if (typeProcCallOut.hasNext()) {
                throw new Exception("La chiamata a procedura: " + procCall.getId().getLessema() + ". Il numero dei tipi richiesti: " + symbolType.getInTypeList().size() + "è minore del numero dei tipi forniti.");
            }
        }
        if (typeIterIn.hasNext()) {
            throw new RuntimeException("La chiamata a procedura: " + procCall.getId().getLessema() + ". Il numero dei tipi richiesti: " + symbolType.getInTypeList().size() + " è maggiore del numero dei tipi forniti");
        }
        return null;
    }

    @Override
    public Object visit(Function function) throws Exception {
        //controllo che la function abbia un return, lo controllo usando la nuova classe esterna ReturnCheck
        // che controlla all'interno ai diversi body che ci sono se c'è un return

        if (!CheckReturnFun(function.getCorpo(), function)) {

            throw new Exception("La funzione" + function.getId().getLessema() + "non ha return!");
        }
        currentScope = function.getSymbolTableFunc();

        function.getCorpo().accept(this);

        return null;
    }

    public boolean CheckReturnFun(Body body, Function function) throws Exception {
        currentScope = function.getSymbolTableFunc();
        boolean flag = false;
        for (Statement s : body.getStatement()) {
            //controllo che tutti i return restituiscano il numero di valori e di tipi corretti
            if (s instanceof ReturnOP) {
                SymbolType symbolType = (SymbolType) s.accept(this);
                Iterator<Type> returnTypeOut = symbolType.getOutTypeList().iterator();
                Iterator<Type> funTypeOut = function.getTipi().iterator();

                //controllo che il tipo di ritorno combaci con il tipo di ritorno della funzione
                while (funTypeOut.hasNext() && returnTypeOut.hasNext()) {

                    Type funType = funTypeOut.next();
                    Type returnType = returnTypeOut.next();
                    if (!funType.getTipo().equals(returnType.getTipo())) {
                        throw new Exception("Funzione: " + function.getId().getLessema() + ". Tipo di ritorno: " + returnType.getTipo() + " non combacia con il tipo di ritorno della funzione");
                    }
                }

                if (funTypeOut.hasNext()) {
                    throw new Exception("Funzione: " + function.getId().getLessema() + ". La funzione si aspetta più elementi di ritorno.");
                } else if (returnTypeOut.hasNext()) {
                    throw new RuntimeException("Funzione: " + function.getId().getLessema() + ". Il return ha più elementi di quanti se ne aspetta la funzione.");
                }
                flag = true;

                //se lo statement è un if controlla che il return, s enon è presnete nel body,
                //deve essere presente e deve essere corretto in ogni body dell'if, elseif ed else

            } else if (s instanceof IfStatOp ifStatOp) {

                boolean elifFlag = true;
                if (ifStatOp.getListelif() != null) {
                    for (ElifOp elifOp : ifStatOp.getListelif()) {
                        if (!CheckReturnFun(elifOp.getCorpo(), function)) {
                            elifFlag = false;
                            break;
                        }
                    }
                }

                flag = flag || CheckReturnFun(ifStatOp.getCorpo(), function)
                        && CheckReturnFun(ifStatOp.getElseBody(), function)
                        && elifFlag;
                //Se lo statement è un while controlla se il return è presente e corretto
            } else if (s instanceof WhileOP whileOP) {
                flag = flag || CheckReturnFun(whileOP.getCorpo(), function);
            }
        }
        return flag;
    }


    @Override
    public Object visit(FuncParams funcParams) throws Exception {
        return null;
    }

    @Override
    public Object visit(FunCall funCall) throws Exception {

        SymbolType symbolType = (SymbolType) funCall.getId().accept(this);
        //iteratore tipi di controllo
        Iterator<Type> typeIter = symbolType.getInTypeList().iterator();

        //System.out.println("facall: "+funCall.getExprs());

        //controllo che ogni parametro abbia lo stesso tipo del rispettivo parametro nella firma
        if (funCall.getExprs() != null && !funCall.getExprs().isEmpty()) {
            for (Expr e : funCall.getExprs()) {

                //System.out.println("espr: " + e);

                SymbolType symbolTypeFun = (SymbolType) e.accept(this);

                //controllo che restituisca un solo valore
                if (e instanceof FunCall && symbolTypeFun.getOutTypeList().size() != 1) {
                    throw new Exception("La chiamata a funzione non può essere passata come argomento poichè restituisce più valori");
                }

                Iterator<Type> typeIterFunOut = symbolTypeFun.getInTypeList().iterator();

                //System.out.println("typeiter: " + typeIter.hasNext());
                //System.out.println("typeiterfunout: " + typeIterFunOut.hasNext());

                while (typeIter.hasNext() && typeIterFunOut.hasNext()) {
                    Type funCallType = typeIterFunOut.next();
                    Type type = typeIter.next();

                    //controllo che i tipi combacino
                    if (!funCallType.getTipo().equals(type.getTipo()))
                        throw new Exception("Chiamata funzione: " + funCall.getId().getLessema() + ". Il tipo: " + funCallType.getTipo() + " non combacia con il tipo: " + type.getTipo());

                }
                if (typeIterFunOut.hasNext()) {
                    throw new Exception("Chiamata funzione: " + funCall.getId().getLessema() + ". Il numero dei tipi richiesti: " + symbolType.getInTypeList().size() + " è minore del numero dei tipi forniti.");
                }
            }
        }
        if (typeIter.hasNext()) {
            throw new Exception("Chiamata funzione: " + funCall.getId().getLessema() + ". Il numero dei tipi richiesti: " + symbolType.getInTypeList().size() + " è maggiore del numero dei tipi forniti.");
        }
        return symbolType;
    }

    @Override
    public Object visit(DeclsOP declsOP) throws Exception {

        // se il tipo non c'è
        if (declsOP.getTipo() == null) {
            //controllo che il numero degli id sia uguale al numero delle costanti
            if (declsOP.getId().size() != declsOP.getCostanti().size()) {
                throw new Exception("il numero di id: " + declsOP.getId().size() + " è diverso dal numero delle costanti: " + declsOP.getCostanti().size());
            }
        }
        return null;
    }

    @Override
    public Object visit(Body body) throws Exception {


        for (DeclsOP d : body.getVardecls()) {
            d.accept(this);
        }

        for (Statement s : body.getStatement()) {
            s.accept(this);
        }

        return null;
    }

    @Override
    public Object visit(AssignOP assignOP) throws Exception {
        ArrayList<Identifier> listaId = assignOP.getIds();
        ArrayList<Expr> listaExpr = assignOP.getExprs();
        //Verifico che il numero di identificatori coincide con numero di espressioni
        if (listaId.size() == listaExpr.size()) { //Controllo se le due liste hanno la stessa size
            for (int i = 0; i < listaId.size(); i++) {
                if (currentScope.lookup(listaId.get(i).getLessema()).getProperties().equals("immutable")) {
                    throw new Exception(" L'id: " + listaId.get(i).getLessema() + "non può essere assegnato");
                }

                SymbolType typeIdSymbolType = (SymbolType) listaId.get(i).accept(this);
                String typeId = (String) typeIdSymbolType.getInTypeList().get(i).getTipo();

                SymbolType typeExprSymbolType = (SymbolType) listaExpr.get(i).accept(this);
                String typeExpr = (String) typeExprSymbolType.getInTypeList().get(i).getTipo();

                if (!typeId.equals(typeExpr))
                    throw new RuntimeException("Il tipo dell'id: " + listaId.get(i).getLessema() + " non coincide con il tipo della rispettiva espressione");
            }
        } else {
            throw new RuntimeException();
        }
        return null;
    }


    @Override
    public Object visit(ElifOp elifOp) throws Exception {

        SymbolTable temp = currentScope;

        SymbolType tipoCondizioneSymbolType = (SymbolType) elifOp.getEspressione().accept(this);

        String tipoCondizione = tipoCondizioneSymbolType.getInTypeList().get(0).getTipo();
        if (!tipoCondizione.equals("boolean")) {
            throw new Exception("L'espressione della condizione non è di tipo boolean!");
        }

        currentScope = elifOp.getSymbolTableElIf();
        elifOp.getCorpo().accept(this);

        currentScope = temp;
        return null;
    }

    @Override
    public Object visit(IfStatOp ifStatOp) throws Exception {

        SymbolTable temp = currentScope;

        SymbolType tipoCondizioneSymbolType = (SymbolType) ifStatOp.getExpr().accept(this);

        String tipoCondizione = tipoCondizioneSymbolType.getInTypeList().get(0).getTipo();
        //controllo che l'espressione sia di tipo boolean
        if (!tipoCondizione.equals("boolean")) {
            throw new Exception("L'espressione della condizione non è di tipo boolean!");
        }

        //accetto l'espressione e il body dell'if
        currentScope = ifStatOp.getSymbolTableIf();
        ifStatOp.getCorpo().accept(this);

        //risetto il current a quello precedente
        currentScope = temp;

        //controllo che la lista di else if non sia vuota, se non è vuota accetto
        if (ifStatOp.getListelif() != null) {
            for (ElifOp elseif : ifStatOp.getListelif()) {
                elseif.accept(this);
            }
        }
        //entro nello scope dell'else
        currentScope = ifStatOp.getSymbolTableElse();

        //controllo che il corpo dell'else esista se esiste accetto il suo body
        if (ifStatOp.getElseBody() != null) {

            ifStatOp.getElseBody().accept(this);
        }
        //risetto il current al precendente dell'else
        currentScope = temp;

        return null;
    }

    @Override
    public Object visit(ReadOP readOP) throws Exception {

        for (Expr e : readOP.getIoargs()) {
            if (!(e instanceof Identifier) && e.getMode() != null && e.getMode().equals("DOLLAR")) {
                //eccezione non è un'id
            }
            e.accept(this);
        }

        return null;
    }

    @Override

    //bisogna resituire una symbolType
    public Object visit(ReturnOP returnOP) throws Exception {

        SymbolType combinedSymbolType = new SymbolType(new ArrayList<>(), new ArrayList<>());
        //prendo la lista di espressioni
        // ArrayList<Type> typeList = new ArrayList<>();

        for (Expr e : returnOP.getExprs()) {
            SymbolType symbolType = (SymbolType) e.accept(this);
            //System.out.println(symbolType);
            // typeList.addAll(symbolType.getOutTypeList());
            // Aggiungo tutti i tipi di ritorno della SymbolType combinata
            if(e instanceof FunCall){
                combinedSymbolType.addOutTypeList(symbolType.getOutTypeList());
            } else {
                combinedSymbolType.addOutTypeList(symbolType.getInTypeList());
            }
        }
        if (combinedSymbolType != null) {
            return combinedSymbolType;
        } else
            throw new Exception("Il return deve restituire almeno un tipo di ritorno");
    }

    @Override
    public Object visit(Statement statement) throws Exception {

        if (statement instanceof AssignOP) {
            ((AssignOP) statement).accept(this);
        }
        if (statement instanceof ProcCall) {
            ((ProcCall) statement).accept(this);
        }

        if (statement instanceof ReturnOP) {
            ((ReturnOP) statement).accept(this);
        }

        if (statement instanceof WriteOP) {
            ((WriteOP) statement).accept(this);
        }

        if (statement instanceof WriteReturnOP) {
            ((WriteReturnOP) statement).accept(this);
        }

        if (statement instanceof ReadOP) {
            ((ReadOP) statement).accept(this);
        }

        if (statement instanceof IfStatOp) {
            ((IfStatOp) statement).accept(this);
        }

        if (statement instanceof WhileOP) {
            ((WhileOP) statement).accept(this);
        }
        return null;
    }

    @Override
    public Object visit(WhileOP whileOP) throws Exception {

        SymbolType conditionSymbolType = (SymbolType) whileOP.getEspressione().accept(this);
        String condition = conditionSymbolType.getInTypeList().get(0).getTipo();

        //String condition= (String )whileOP.getEspressione().accept(this);

        if (!condition.equals("boolean")) {
            throw new Exception("condizione non valida non è boolean");
        }
        //entro nello scope
        currentScope = whileOP.getSymbolTable();
        whileOP.getCorpo().accept(this);
        //esco dallo scope
        currentScope = whileOP.getSymbolTable().getFather();

        return null;
    }

    @Override
    public Object visit(WriteOP writeOP) throws Exception {

        for (Expr e : writeOP.getIoargs()) {
            e.accept(this);
        }
        return null;
    }

    @Override
    public Object visit(WriteReturnOP writeReturnOP) throws Exception {

        for (Expr e : writeReturnOP.getIoargs()) {
            e.accept(this);
        }
        return null;
    }

    @Override
    public Object visit(ConstOp constOp) throws Exception {
        String type = constOp.getCostante();
        ////System.out.println("tipo: "+ type);
        if (type.equals("real_const") || type.equals("real")) {
            constOp.setExprType("real");
            return new SymbolType(new Type("real"));
        }
        if (type.equals("integer_const") || type.equals("integer")) {
            constOp.setExprType("integer");
            return new SymbolType(new Type("integer"));
        }
        if (type.equals("string_const") || type.equals("string")) {
            constOp.setExprType("string");
            return new SymbolType(new Type("string"));
        }
        if (type.equals("boolean_const") || type.equals("boolean")) {
            constOp.setExprType("boolean");
            return new SymbolType(new Type("boolean"));
        }
        if(type.equals("rgb_const") || type.equals("rgb")){
            constOp.setExprType("rgb");
            return new SymbolType(new Type("rgb"));
        }
        return null;
    }

    @Override
    public Object visit(Expr expr) throws Exception {
        return null;
    }

    @Override
    public Object visit(Identifier identifier) throws Exception {

        SymbolTable temp = currentScope;

        while (currentScope != null) {
            SymbolTableRow result = currentScope.lookup(identifier.getLessema());

            if (result != null) {
                SymbolType type = result.getType();

                currentScope = temp;
                if (type.getInTypeList().size()>0)
                    identifier.setExprType(type.getInTypeList().get(0).getTipo());
                else
                    identifier.setExprType(type.getOutTypeList().get(0).getTipo());
                return type;

            } else {
                currentScope = currentScope.getFather();
            }
        }
        throw new Exceptions.NoDeclaration(identifier.getLessema());
    }

    @Override
    public Object visit(Relop relop) throws Exception {
        //otteniamo il tipo delle espressioni 1 e 2

        SymbolType typeExpr1SymbolType = (SymbolType) relop.getExpr1().accept(this);
        String typeExpr1 = typeExpr1SymbolType.getInTypeList().get(0).getTipo();

        SymbolType typeExpr2SymbolType = (SymbolType) relop.getExpr2().accept(this);
        String typeExpr2 = typeExpr2SymbolType.getInTypeList().get(0).getTipo();

        if (typeExpr1.contains("string")) {
            typeExpr1 = "string";
        } else if (typeExpr1.contains("integer")) {
            typeExpr1 = "integer";
        } else if (typeExpr1.contains("real")) {
            typeExpr1 = "real";
        } else if(typeExpr1.contains("rgb")){
            typeExpr1= "rgb";
        }

        if (typeExpr2.contains("string")) {
            typeExpr2 = "string";
        } else if (typeExpr2.contains("integer")) {
            typeExpr2 = "integer";
        } else if (typeExpr1.contains("real")) {
            typeExpr1 = "real";
        } else if(typeExpr2.contains("rgb")){
            typeExpr2= "rgb";
        }


        //otteniamo il tipo dell'operazione
        String typeOp = relop.getTipoOp();

        //combinazione aritmetica
        if ((typeOp.equals("PlusOp") ) || typeOp.equals("MinusOp") || typeOp.equals("TimesOp") || typeOp.equals("DivOp")) {
            for (String[] c : combinazioniAritmetiche) {
                if (typeExpr1.equals(c[0]) && typeExpr2.equals(c[1])) {
                    relop.setEspressione(c[2]);
                    relop.setExprType(c[2]);
                    return new SymbolType(new Type(c[2]));
                }
            }
        }

        // combinazione di concatenazione di stringhe
        if (typeOp.equals("PlusOp") && (typeExpr1.contains("string") || typeExpr2.contains("string"))) {
            for (String[] c : combinazioneConcat) {
                if (typeExpr1.equals(c[0]) && typeExpr2.equals(c[1])) {
                    relop.setEspressione(c[2]);
                    relop.setExprType(c[2]);

                    return new SymbolType(new Type(c[2]));
                }
            }
            throw new Exception("Operazione non consentita:" + relop.getEspressione());
        }

        //combinazione relazione
        if (typeOp.equals("GTOp") || typeOp.equals("GEOp") || typeOp.equals("LTOp") || typeOp.equals("LEOp") || typeOp.equals("EQOp") || typeOp.equals("NEOp")) {
            for (String[] c : combinazioniRelOp) {
                if (typeExpr1.equals(c[0]) && typeExpr2.equals(c[1])) {
                    relop.setEspressione(c[2]);
                    relop.setExprType(c[2]);

                    return new SymbolType(new Type(c[2]));
                }
            }
            throw new Exception("Operazione non consentita:" + relop.getEspressione());
        }

        //combinazione booleana and e or
        if (typeOp.equals("AndOp") || typeOp.equals("OrOp")) {
            for (String[] c : combinazioniBoolean) {
                if (typeExpr1.equals(c[0]) && typeExpr2.equals(c[1])) {
                    relop.setEspressione(c[2]);
                    relop.setExprType(c[2]);

                    return new SymbolType(new Type(c[2]));
                }
            }
            throw new Exception("Operazione non consentita:" + relop.getEspressione());
        }
        return null;
    }

    @Override
    public Object visit(UnaryOp unaryOp) throws Exception {

        String typeExpr = (String) unaryOp.getExpr().accept(this);
        String type = unaryOp.getType();


        if (type.equals("UminusOp")) {
            for (String[] c : combinazioniMinus) {
                if (typeExpr.contains(c[0])) {
                    unaryOp.setType(c[1]);
                    unaryOp.setExprType(c[0]);
                    return new SymbolType(new Type(c[1]));
                }
            }
            throw new Exception("Operazione non consentita:" + unaryOp.getEspressione());
        }

        if (type.equals("NotOp")) {
            for (String[] c : combinazioniNot) {
                if (typeExpr.contains(c[0])) {
                    unaryOp.setType(c[1]);
                    unaryOp.setExprType(c[0]);
                    return new SymbolType(new Type(c[1]));
                }
            }
            throw new Exception("Operazione non consentita:" + unaryOp.getEspressione());
        }
        return null;
    }

    @Override
    public Object visit(IfuncOP ifuncOP) throws Exception {

        if (!CheckReturnIFun(ifuncOP.getBodyIfunc(), ifuncOP)) {

            throw new Exception("La ifunzione" + ifuncOP.getId().getLessema() + "non ha return!");
        }
        currentScope = ifuncOP.getSymbolTableIfunc();

        ifuncOP.getBodyIfunc().accept(this);

        return null;
    }

    public boolean CheckReturnIFun(Body body, IfuncOP ifuncOP) throws Exception {
        currentScope = ifuncOP.getSymbolTableIfunc();
        boolean flag = false;
        for (Statement s : body.getStatement()) {
            //controllo che tutti i return restituiscano il numero di valori e di tipi corretti
            if (s instanceof ReturnOP) {
                SymbolType symbolType = (SymbolType) s.accept(this);


                String returnTypeOut= symbolType.getOutTypeList().get(0).getTipo();
                //Iterator<Type> returnTypeOut = symbolType.getOutTypeList().iterator();

               //System.out.println(returnTypeOut);


                //prendo il tipo in out della funzione intera
                String funTypeOut= currentScope.lookup(ifuncOP.getId().getLessema()).getType().getOutTypeList().get(0).getTipo();

                //System.out.println(funTypeOut);
                //Iterator<Type> funTypeOut = ifuncOP.getTipi().iterator();

                //controllo che il tipo di ritorno combaci con il tipo di ritorno della funzione
                    if (!funTypeOut.equals(returnTypeOut)) {
                        throw new Exception("Funzione: " + ifuncOP.getId().getLessema() + ". Tipo di ritorno: " + returnTypeOut + " non combacia con il tipo di ritorno della funzione");
                    }

                flag = true;

                //se lo statement è un if controlla che il return, s enon è presnete nel body,
                //deve essere presente e deve essere corretto in ogni body dell'if, elseif ed else

            } else if (s instanceof IfStatOp ifStatOp) {

                boolean elifFlag = true;
                if (ifStatOp.getListelif() != null) {
                    for (ElifOp elifOp : ifStatOp.getListelif()) {
                        if (!CheckReturnIFun(elifOp.getCorpo(), ifuncOP)) {
                            elifFlag = false;
                            break;
                        }
                    }
                }

                flag = flag || CheckReturnIFun(ifStatOp.getCorpo(), ifuncOP)
                        && CheckReturnIFun(ifStatOp.getElseBody(), ifuncOP)
                        && elifFlag;
                //Se lo statement è un while controlla se il return è presente e corretto
            } else if (s instanceof WhileOP whileOP) {
                flag = flag || CheckReturnIFun(whileOP.getCorpo(), ifuncOP);
            }
        }
        return flag;
    }




}